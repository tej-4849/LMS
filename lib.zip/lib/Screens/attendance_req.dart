
import 'package:delightful_toast/delight_toast.dart';
import 'package:delightful_toast/toast/components/toast_card.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/utilities/profilepage/profile_info.dart';


class AttendanceReq extends StatelessWidget {
  const AttendanceReq({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0,vertical: 15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 255, 62, 62),
                  borderRadius: BorderRadius.circular(15)
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Text("Submit your attendance increment form", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25, color: Colors.white),),
                )),
        
              const SizedBox(height: 30,),

              Container(
                height: 800,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 84, 107, 255),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Column(
                  children: [
                    ProfileInfo(what: "Name", value: "Sarvesh Kamtekar"),
              ProfileInfo(what: "PRN", value: "2223001023"),
              ProfileInfo(what: "Year", value: "Third"),
              ProfileInfo(what: "Department", value: "Computer Science"),
        
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 15),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        
                        Text("Your Application", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                        
                      ],
                    ),
        
                    const SizedBox(height: 20,),
        
                    Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 222, 222, 222),
                        borderRadius: BorderRadius.circular(15)
                      ),
                      
                      child: TextField(
                        maxLines: null,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide.none
                          )
                          
                        ),
                      ),
                    )
                  ],
                ),
              ) ,
              const SizedBox(height: 30,),


              GestureDetector(
                onTap: (){
                  showDialog(
                  context: context, 
                  builder: (BuildContext context){
                    return AlertDialog(
                      title: Text('Confirmation'),
                      content: Text("Are you sure you want to submit?"),
                      actions: [
                        TextButton(onPressed: (){Navigator.of(context).pop();}, child: Text('Cancel')),
                        TextButton(onPressed: (){
                          Navigator.of(context).pop();
                          DelightToastBar(builder: (context)=>const ToastCard(
                            leading: Icon(Icons.check, color: Colors.green,),
                            title: Text("Application Submitted !!", style: TextStyle(fontWeight: FontWeight.bold),)
                          )).show(context);

                          }, child: Text('Submit')),
                        
                      ],
                    );
                  });
                },
                child: Container(
                  height: 60,
                  width: 140,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(15)
                  ),
                  child: Center(child: Text("SUBMIT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),)),
                  
                ),
              )         

                  ],
                ),
              ),

                          ],
          ),
        ),
      ),



    );
  }
}