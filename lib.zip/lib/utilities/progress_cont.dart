import 'package:flutter/material.dart';
import 'package:notesapp/pages/student_show_courses.dart';

class ProgressCont extends StatelessWidget {
  final Map<String, dynamic> studentData;
  const ProgressCont({super.key, required this.studentData});

  @override
  Widget build(BuildContext context) {
    return Padding(
                  padding: const EdgeInsets.only(left: 30.0, right: 30),
                  child: Container(
                    height: 120,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 15,
                          spreadRadius: 1,
                          color: Colors.grey
                        )
                      ],
                      borderRadius: BorderRadius.circular(15)
                    ),

                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Text("Learned today", style: TextStyle(color: Color.fromARGB(255, 85, 85, 85), fontSize: 15, fontWeight: FontWeight.bold),),
                            const SizedBox(height: 5,),
                            Row(mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text("46min", style: TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 25, fontWeight: FontWeight.bold),),
                                
                                Text("/60min", style: TextStyle(color: Color.fromARGB(255, 143, 143, 143), fontSize: 13, fontWeight: FontWeight.bold),),
                              ],
                            ),

                            const SizedBox(height: 5,),

                            SizedBox(
                              width: 200,
                              child: LinearProgressIndicator(
                                value: 40/60,
                                backgroundColor: Colors.grey,
                                color: Colors.green,
                                minHeight: 5,
                              ),
                            )

                            

                            
                          ],
                        ),

                        GestureDetector(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>StudentShowCourses(studentData: studentData,)));
                          },
                          child: Text("My Courses", style: TextStyle(color: Color.fromARGB(255, 33, 103, 243)),))
                      ],
                    ),
                  ),
                );
  }
}