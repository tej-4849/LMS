import 'package:flutter/material.dart';
import 'package:notesapp/Screens/attendance_req.dart';
import 'package:notesapp/utilities/module_cont.dart';


class ModuleScroll extends StatelessWidget {
  const ModuleScroll({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
                  padding: const EdgeInsets.only(left: 20.0,right: 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left:10.0),
                        child: Text("Modules",  style: TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 20, fontWeight: FontWeight.bold)),
                      ),
                  
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Row(
                            children: [
                              ModuleCont(icon: Icon(Icons.file_copy), name: 'Assignments\ntest'),

                              ModuleCont(icon: Icon(Icons.stacked_bar_chart_rounded), name: 'Academic\nPlanning'),

                              ModuleCont(icon: Icon(Icons.wallet_giftcard), name: 'Certificates'),

                              ModuleCont(icon: Icon(Icons.calendar_month_rounded), name: 'Events'),
                              
                              ModuleCont(icon: Icon(Icons.feedback_outlined), name: 'Feedback'),

                              ModuleCont(icon: Icon(Icons.attach_money_rounded), name: 'Fees'),

                              ModuleCont(icon: Icon(Icons.grade_sharp), name: 'Leaderboard'),

                              ModuleCont(icon: Icon(Icons.book), name: 'Library'),

                              GestureDetector(
                                onTap: (){
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=>AttendanceReq()));
                                },
                                child: ModuleCont(icon: Icon(Icons.account_balance_outlined), name: 'Attendace\nApplication')),
                              
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                );
  }
}