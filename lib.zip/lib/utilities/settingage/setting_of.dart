import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/utilities/settingage/setting_of_switch.dart';


class SettingOf extends StatelessWidget {
  final String name;
  final IconData icon;
  final bool isSwitch;

  SettingOf({required this.name, required this.icon, required this.isSwitch});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
      child: Container(
        height: 70,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(15)
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal:  10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
          
            children: [
              Text(name, style: TextStyle(fontSize: 15),),

              isSwitch? SettingOfSwitch() :  Icon(icon, color: Colors.black,)
            ],
          ),
        ),
      ),
    );
  }
}