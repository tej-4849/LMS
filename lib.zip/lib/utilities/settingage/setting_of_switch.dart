import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SettingOfSwitch extends StatefulWidget {
  

  @override
  State<SettingOfSwitch> createState() => _SettingOfSwitchState();
}

class _SettingOfSwitchState extends State<SettingOfSwitch> {
  bool _lights = false;

  @override
  Widget build(BuildContext context) {
    

    return Switch.adaptive(
      value:_lights, 
      onChanged: (bool value){
        setState((){
          _lights = value;
        });
      });
  }
}