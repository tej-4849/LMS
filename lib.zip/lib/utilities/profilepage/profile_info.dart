import 'package:flutter/material.dart';

class ProfileInfo extends StatelessWidget {
  final String what;
  final String value;
  
  ProfileInfo({required this.what, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(what, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
            ],
          ),

          const SizedBox(height: 10,),
      
          Container(
            height: 50,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(10)
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  
                  Text(value,style: TextStyle(fontSize: 17,),),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}