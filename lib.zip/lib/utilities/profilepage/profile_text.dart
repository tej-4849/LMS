import 'package:flutter/material.dart';

class ProfileText extends StatelessWidget {
  const ProfileText({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Profile", style: TextStyle(fontSize: 30,),textAlign: TextAlign.center,),
            ],
          );
  }
}