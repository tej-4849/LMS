class TimeSlot {
  final String time;
  final String subject;
  final String faculty;

  TimeSlot({required this.time,  required this.subject, required this.faculty});

  // converting timeslot object to map for storing in firebase..?
  Map<String, dynamic> toMap(){
    return {
      'time' : time,
      'subject' : subject,
      "faculty" : faculty
    };
  }

  // convert firestore document to timeslot object
  factory TimeSlot.fromMap(Map<String, dynamic> map){
    return TimeSlot(
      time: map['time']?? '', 
      subject: map['subject'] ?? '', 
      faculty: map['faculty']
      );
  }
}