import 'package:flutter/material.dart';

class MyTextfield extends StatelessWidget {
  final TextEditingController textEditingController;
  final String hintText;
  MyTextfield({required this.textEditingController, required this.hintText});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 30),
      
      child: TextField(
        controller: textEditingController,
        
        decoration: InputDecoration(
            hintText: hintText,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
    );
  }
}
