import 'package:flutter/material.dart';

class MyUserListview extends StatelessWidget {
  final String name;
  final String email;
  final String password;
  final String? subject;
  final String? prn;
  final String? year;
  final String? division;
  
  final TextStyle infoTextStyle = TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white);
  final TextStyle subinfoTextStyle = TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white);
  MyUserListview({required this.name, required this.email, required this.password, this.subject, this.prn, this.year, this.division, });

  @override
  Widget build(BuildContext context) {
    return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          child: Container(
            
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              color: const Color.fromARGB(255, 83, 119, 239),
              boxShadow: [
                BoxShadow(
                  spreadRadius: 1,
                  blurRadius: 5,
                  color: Colors.grey.withOpacity(0.5),
                )
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Name: ${name}", style: infoTextStyle,),
                  Text("Email: ${email}", style: subinfoTextStyle,),
                  Text("password: ${password}", style: subinfoTextStyle,), 
                  if(subject!= null) Text("Subject: ${subject}", style: subinfoTextStyle,),
                  if(prn!= null) Text("prn: ${prn}", style: subinfoTextStyle,),
                  if(year!=null) Text("year: ${year}", style: subinfoTextStyle,),
                  if(division!=null) Text("division: ${division}", style: subinfoTextStyle,),

                ],
              ),
            ),
          ),
        );
  }
}