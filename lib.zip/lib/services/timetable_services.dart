import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:notesapp/timetables/models/time_slot.dart';

class TimetableServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // add time slot
  Future<void> addTimeSlot({required String year, required String division, required String day, required TimeSlot timeSlot}) async {
    try {
      await _firestore.collection('users').doc('hod').collection('timetables').doc(year).collection('divisions').doc(division).collection('days').doc(day).collection('timeSlots').doc(timeSlot.time).set(timeSlot.toMap());

    }catch(e){
      print("Error adding time slot: $e");
    }
  }

  // fetch time slots 
  Stream <List<TimeSlot>> getTimeSlots({required String year, required String division, required String day}){
    return _firestore.collection('users').doc('hod').collection('timetables').doc(year).collection('divisions').doc(division).collection('days').doc(day).collection('timeslots').snapshots().map((snapshots){
      return snapshots.docs.map((doc) => TimeSlot.fromMap(doc.data())).toList();
    });
  }

  // delete time slots
  Future<void> deleteTimeSlot({required String year, required String division, required String day, required String time}) async
  {
    try {
      await _firestore.collection('users').doc('hod').collection('timetables').doc(year).collection('divisions').doc(division).collection('days').doc(day).collection('timeSlots').doc(time).delete();
    }
    catch(e){
      print("Error deleting time slots : $e");
    }
  }
}