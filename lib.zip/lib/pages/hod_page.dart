import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/elements/my_textfield.dart';
import 'package:notesapp/pages/add_users_page.dart';
import 'package:notesapp/pages/create_time_table_screen.dart';
import 'package:notesapp/pages/hod_leave_view_page.dart';
import 'package:notesapp/pages/show_std_page.dart';
import 'package:notesapp/pages/show_teacher_page.dart';
import 'package:notesapp/pages/view_time_table_screen.dart';
import 'package:notesapp/services/firestore.dart';

class HodPage extends StatefulWidget {
  Map<String, dynamic> userData;
  HodPage({super.key, required this.userData});

  @override
  State<HodPage> createState() => _HodPageState();
}

class _HodPageState extends State<HodPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    firestoreService.debugTestTeachers();
  }

  final FirestoreService firestoreService = FirestoreService();
  final TextStyle generalTextStyle = TextStyle(fontSize: 20, fontWeight: FontWeight.bold);
  final TextStyle buttonTextStyle = TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white);

  //controllers shit
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController stdnameController = TextEditingController();
  final TextEditingController stdemailController = TextEditingController();
  final TextEditingController stdpasswordController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();
  final TextEditingController prnController = TextEditingController();
  final TextEditingController divisionController = TextEditingController();
  final TextEditingController yearController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("HOD's PAGE"),
        centerTitle: true,
      ),

      body: FutureBuilder(
        future: firestoreService.getHodData(),
        builder: (context, snapshot){
          if(snapshot.connectionState == ConnectionState.waiting){
            return Center(child: CircularProgressIndicator(),);
          }
          if(snapshot.hasError){
            return Center(child: Text("Some Error occured"),);
          }
          if(!snapshot.hasData){
            return Center(child: Text('no data of hod found'),);
          }

          // else shit here
          DocumentSnapshot hodData = snapshot.data!;
          final Map<String, dynamic> mappedHodData = hodData.data() as Map<String, dynamic>;
          String hodName = mappedHodData['name'] ?? 'Kingmaker';
          
          return SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // name shit
                  
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Welcome $hodName', style: generalTextStyle,),
                    ],
                  ),

                  const SizedBox(height: 30,),

                  // top navigator shit
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AddUsersPage()));
                        },
                        child: Container(
                          height: 150,
                          width: 150,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(15),
                            
                          ),
                          child: Center(child: Text("Create Users", style: buttonTextStyle,)),
                        ),
                      ),

                      GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ShowTeacherPage()));
                        },
                        child: Container(
                          height: 150,
                          width: 150,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(15),
                            
                          ),
                          child: Center(child: Text("Show Created\nTeachers", style: buttonTextStyle,)),
                        ),
                      )
                    ],
                  ),

                  const SizedBox(height: 30,),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ShowStdPage()));
                        },
                        child: Container(
                          height: 150,
                          width: 150,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(15),
                            
                          ),
                          child: Center(child: Text("Show Created\nStudents", style: buttonTextStyle,)),
                        ),
                      ),

                      GestureDetector(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>HodLeaveViewPage()));
                        },
                        child: Container(
                          height: 150,
                          width: 150,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(15),
                            
                          ),
                          child: Center(child: Text("Received\nLeaves", style: buttonTextStyle,)),
                        ),
                      )
                    ],
                  ),
                  
                  const SizedBox(height: 30),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>CreateTimeTableScreen()));
                        },
                        child: Container(
                          height: 150,
                          width: 150,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(15)
                          ),
                          child: Center(child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text("Make", style: buttonTextStyle,),
                              Text("Time-Table", style: buttonTextStyle,)
                            ],
                          )),
                        ),
                      ),

                      GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewTimetableScreen()));
                        },
                        child: Container(
                          height: 150,
                          width: 150,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(15)
                          ),
                          child: Center(child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text("View Created", style: buttonTextStyle,),
                              Text("Time-table", style: buttonTextStyle,)
                            ],
                          )),
                        ),
                      )
                    ],
                  ),
            
                  const SizedBox(height: 30,),
                ],
              ),
            ),
          );


        })
    );

  }
}