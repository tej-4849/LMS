import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'folder_details_screen.dart';

class StudyMaterialScreen extends StatefulWidget {
  final String teacherId; // Pass the teacher's ID
  StudyMaterialScreen({required this.teacherId});

  @override
  _StudyMaterialScreenState createState() => _StudyMaterialScreenState();
}

class _StudyMaterialScreenState extends State<StudyMaterialScreen> {
  void _createFolder() async {
    TextEditingController folderController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Create Folder"),
        content: TextField(
          controller: folderController,
          decoration: InputDecoration(hintText: "Enter folder name"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () async {
              String folderName = folderController.text.trim();
              if (folderName.isNotEmpty) {
                await FirebaseFirestore.instance
                    .collection('users')
                    .doc('teacheruser')
                    .collection('teachers')
                    .doc(widget.teacherId)
                    .collection('studyMaterials')
                    .add({
                  'folderName': folderName,
                  'createdAt': Timestamp.now(),
                });

                Navigator.pop(context);
              }
            },
            child: Text("Create"),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteFolder(String folderId) async{
    bool confirmDelete = await _showDeleteConfirmation();
    if(!confirmDelete) return;

    try{
      // delete folder document
      await FirebaseFirestore.instance
      .collection('users')
      .doc('teacheruser')
      .collection('teachers')
      .doc(widget.teacherId)
      .collection('studyMaterials')
      .doc(folderId)
      .delete();
    } catch(e){
      print("error in deleting folder");
    }

  }
  Future<bool> _showDeleteConfirmation() async{
    return await showDialog(context: context,
    builder: (context) => AlertDialog(
      title: Text("Confirm Delete"),
      content: Text("Are you sure you want to delete this folder?"),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Cancel")),
        TextButton(onPressed: () => Navigator.pop(context, true), child: Text("Delete", style: TextStyle(color: Colors.red),))
      ],
    ))?? false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Study Materials")),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(widget.teacherId)
            .collection('studyMaterials')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("No folders created"));
          }

          return ListView(
            children: snapshot.data!.docs.map((folder) {
              Timestamp createdAt = folder['createdAt'];
              DateTime createdAtDate = createdAt.toDate();
              String formattedDate = DateFormat('dd MMM yyyy, hh:mm a').format(createdAtDate);
              return GestureDetector(


                onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => FolderDetailScreen(
                            teacherId: widget.teacherId,
                            folderId: folder.id,
                            folderName: folder['folderName'],
                          ),
                        ),
                      );
                    },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 91, 97, 255),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0), 
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(folder['folderName'], style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),),
                              Text(formattedDate, style: TextStyle(color: const Color.fromARGB(255, 222, 222, 222), fontSize: 15, fontWeight: FontWeight.bold),)
                              
                          ],),

                          IconButton(onPressed: () => _deleteFolder(folder.id), icon: Icon(Icons.delete, color: Colors.white,))
                        ],
                      ),
                      
                    ),
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _createFolder,
        child: Icon(Icons.create_new_folder),
      ),
    );
  }
}
