import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'package:url_launcher/url_launcher.dart';

class AssignmentDetailPage extends StatefulWidget {
  final String teacherId;
  final String assignmentId;
  final String assignmentName;

  AssignmentDetailPage({
    required this.teacherId,
    required this.assignmentId,
    required this.assignmentName,
  });

  @override
  _AssignmentDetailPageState createState() => _AssignmentDetailPageState();
}

class _AssignmentDetailPageState extends State<AssignmentDetailPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  bool isUploading = false;

  // 🔹 Upload Assignment PDF
  Future<void> _uploadAssignmentPDF() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      withData: true,
    );

    if (result != null) {
      setState(() => isUploading = true);

      String fileName = result.files.single.name;
      String storagePath = "assignments/${widget.teacherId}/${widget.assignmentId}/$fileName";

      try {
        UploadTask uploadTask;

        if (result.files.single.bytes != null) {
          Uint8List fileBytes = result.files.single.bytes!;
          uploadTask = _storage.ref(storagePath).putData(fileBytes);
        } else {
          File file = File(result.files.single.path!);
          uploadTask = _storage.ref(storagePath).putFile(file);
        }

        TaskSnapshot snapshot = await uploadTask;
        String downloadUrl = await snapshot.ref.getDownloadURL();

        await _firestore
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(widget.teacherId)
            .collection('assignments')
            .doc(widget.assignmentId)
            .set({
          'assignmentFile': downloadUrl,
          'fileName': fileName,
          'uploadedAt': Timestamp.now(),
        }, SetOptions(merge: true));

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Assignment uploaded!")));
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Upload failed!")));
      }

      setState(() => isUploading = false);
    }
  }

  Future<void> _deleteAssignmentPdf(String teacherId, String assignmentId, String fileUrl) async {
    try {
      await FirebaseStorage.instance.refFromURL(fileUrl).delete();
      await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(teacherId)
          .collection('assignments')
          .doc(assignmentId)
          .update({
        'assignmentFile': FieldValue.delete(),
        'fileName': FieldValue.delete(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Assignment PDF deleted")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to delete PDF")),
      );
    }
  }

  void _showMarksDialog(BuildContext context, String teacherId, String assignmentId, String studentId, int currentMarks) {
  TextEditingController marksController = TextEditingController(text: currentMarks == -1 ? "" : currentMarks.toString());

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text("Enter Marks (Out of 10)"),
        content: TextField(
          controller: marksController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: "Marks"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              int? enteredMarks = int.tryParse(marksController.text.trim());
              if (enteredMarks != null && enteredMarks >= 0 && enteredMarks <= 10) {
                await _firestore
                    .collection('users')
                    .doc('teacheruser')
                    .collection('teachers')
                    .doc(teacherId)
                    .collection('assignments')
                    .doc(assignmentId)
                    .collection('submissions')
                    .doc(studentId)
                    .update({'marks': enteredMarks});
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Enter a valid number between 0-10")));
              }
              Navigator.pop(context);
            },
            child: Text("Save"),
          ),
        ],
      );
    },
  );
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.assignmentName, style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color.fromARGB(255, 31, 0, 114),
        foregroundColor: Colors.white,
      ),body: Padding(
  padding: const EdgeInsets.all(16.0),
  child: Column(
    children: [
      // 🟢 Added a SizedBox to prevent content from overlapping the AppBar
      SizedBox(height: 10),

      // 🔵 Assignment Upload and Display Section
      StreamBuilder<DocumentSnapshot>(
        stream: _firestore
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(widget.teacherId)
            .collection('assignments')
            .doc(widget.assignmentId)
            .snapshots(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return Column(
              children: [
                _uploadButton(),
                SizedBox(height: 10),
                Text("No assignment uploaded yet.", style: TextStyle(color: Colors.grey)),
              ],
            );
          }

          var assignmentData = snapshot.data!.data() as Map<String, dynamic>? ?? {};
          String fileUrl = assignmentData['assignmentFile'] ?? "";

          return Column(
            children: [
              if (fileUrl.isEmpty) _uploadButton(),
              if (fileUrl.isNotEmpty)
                Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(16),
                    tileColor: Colors.blueAccent.withOpacity(0.1),
                    leading: Icon(Icons.picture_as_pdf, color: Colors.red, size: 40),
                    title: Text(
                      assignmentData['fileName'] ?? "Unknown File",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text("Tap to view", style: TextStyle(color: Colors.grey)),
                    onTap: () async {
                      if (await canLaunchUrl(Uri.parse(fileUrl))) {
                        await launchUrl(Uri.parse(fileUrl), mode: LaunchMode.externalApplication);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Could not open")));
                      }
                    },
                    trailing: IconButton(
                      onPressed: () => _deleteAssignmentPdf(widget.teacherId, widget.assignmentId, fileUrl),
                      icon: Icon(Icons.delete, color: Colors.red),
                    ),
                  ),
                ),
            ],
          );
        },
      ),

      SizedBox(height: 20),

      // 🟡 Title for Student Submissions
      Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
          child: Text("Student Submissions", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ),
      ),

      // 🔴 Fix: Wrapped ListView in Expanded to prevent layout issues
      Expanded(
        child: StreamBuilder<QuerySnapshot>(
          stream: _firestore
              .collection('users')
              .doc('teacheruser')
              .collection('teachers')
              .doc(widget.teacherId)
              .collection('assignments')
              .doc(widget.assignmentId)
              .collection('submissions')
              .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return Center(
                child: Text("No student submissions yet.", style: TextStyle(color: Colors.grey)),
              );
            }

            return ListView.builder(
              padding: EdgeInsets.only(bottom: 20), // Avoid overlapping bottom elements
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var doc = snapshot.data!.docs[index];
                var submissionData = doc.data() as Map<String, dynamic>;
                String studentName = submissionData['studentName'] ?? "Unknown Student";
                String fileUrl = submissionData['fileUrl'] ?? "";
                String submittedAt = submissionData['submittedAt'] != null
                    ? submissionData['submittedAt'].toDate().toString()
                    : "Unknown Time";
                int marks= submissionData['marks'] ?? -1; 


                return Card(
                  elevation: 4,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    title: Text("$studentName's Submission", style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      children: [
                        Text("Submitted at: $submittedAt"),
                        Text(marks == -1? "Marks Not assigned" : "Marks: ${marks/10}", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue),)
                      
                      ],
                    ),
                    trailing: IconButton(onPressed:() {
                      _showMarksDialog(context, widget.teacherId, widget.assignmentId, doc.id, marks);
                    }, icon: Icon(Icons.edit, color: Colors.green,)
                    ),
                    onTap: () async {
                      if (await canLaunchUrl(Uri.parse(fileUrl))) {
                        await launchUrl(Uri.parse(fileUrl), mode: LaunchMode.externalApplication);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Could not open")));
                      }
                    },
                  ),
                );
              },
            );
          },
        ),
      ),
    ],
  ),
),

    );
  }

  Widget _uploadButton() {
    return GestureDetector(
      onTap: isUploading ? null : _uploadAssignmentPDF,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 5),
        child: Container(
          width: double.infinity,
          height: 100,
          decoration: BoxDecoration(
            
            color: const Color.fromARGB(255, 33, 110, 234),
            borderRadius:  BorderRadius.circular(8),
            
          ),
          child: Center(
            child: Padding(
              padding: EdgeInsets.all(10),
              child: isUploading ? CircularProgressIndicator(color: Colors.white) : Text("Upload the assignment PDF", style: TextStyle(color: Colors.white, fontSize: 25),))),
        ),
      ),
    );
  }
}
