import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LeaveSubmissionPage extends StatefulWidget {
  final bool isStudent; // true for student, false for teacher
  final String userId;
  final String userName;

  LeaveSubmissionPage({
    super.key,
    required this.isStudent,
    required this.userId,
    required this.userName,
  });

  @override
  _LeaveSubmissionPageState createState() => _LeaveSubmissionPageState();
}

class _LeaveSubmissionPageState extends State<LeaveSubmissionPage> {
  final TextEditingController reasonController = TextEditingController();
  DateTime? startDate;
  DateTime? endDate;
  bool isSubmitting = false;

  Future<void> _submitLeave() async {
    if (reasonController.text.isEmpty || startDate == null || endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please fill in all fields before submitting.")),
      );
      return;
    }

    setState(() {
      isSubmitting = true;
    });

    String collectionPath = widget.isStudent ? 'studentleaves' : 'teacherleaves';

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc('hod')
          .collection('leaves')
          .doc(collectionPath)
          .collection(collectionPath)
          .add({
        'userId': widget.userId,
        'name': widget.userName,
        'reason': reasonController.text,
        'startDate': startDate,
        'endDate': endDate,
        'status': 'Pending',
        'timestamp': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Leave application submitted successfully.")),
      );

      // Clear fields after successful submission
      reasonController.clear();
      setState(() {
        startDate = null;
        endDate = null;
        isSubmitting = false;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to submit leave. Try again.")),
      );
    }

    setState(() {
      isSubmitting = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Submit Leave Application", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Reason for Leave",
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 20),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: reasonController,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: "Enter reason for leave",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.blueAccent),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent, width: 2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "Start Date",
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 20),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () async {
                  DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365)),
                  );
                  if (picked != null) {
                    setState(() {
                      startDate = picked;
                    });
                  }
                },
                icon: Icon(Icons.calendar_today, color: Colors.black),
                label: Text(
                  startDate != null
                      ? "${startDate!.toLocal()}".split(' ')[0]
                      : "Select Start Date",
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "End Date",
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 20),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () async {
                  DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365)),
                  );
                  if (picked != null) {
                    setState(() {
                      endDate = picked;
                    });
                  }
                },
                icon: Icon(Icons.calendar_today, color: Colors.black),
                label: Text(
                  endDate != null
                      ? "${endDate!.toLocal()}".split(' ')[0]
                      : "Select End Date",
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                ),
              ),
              const SizedBox(height: 80),

              Center(
                child: ElevatedButton(
                  onPressed: isSubmitting ? null : _submitLeave,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: isSubmitting
                      ? const CircularProgressIndicator(
                          color: Colors.white,
                        )
                      : const Text(
                          "Submit Leave",
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
