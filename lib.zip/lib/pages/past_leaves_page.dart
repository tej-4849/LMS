import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PastLeavesPage extends StatelessWidget {
  final bool isStudent; // true for student, false for teacher
  final String userId;

  const PastLeavesPage({
    super.key,
    required this.isStudent,
    required this.userId,
  });

  Widget _buildPastLeaves(String collectionPath) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc('hod')
          .collection('leaves')
          .doc(collectionPath)
          .collection(collectionPath)
          .where('userId', isEqualTo: userId)
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(
            child: Text(
              "No past leave applications found.",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          );
        }

        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          padding: const EdgeInsets.all(12),
          itemBuilder: (context, index) {
            var leave = snapshot.data!.docs[index];
            var startDate = leave['startDate'].toDate();
            var endDate = leave['endDate'].toDate();
            var status = leave['status'];

            return Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                title: Text(
                  "Reason: ${leave['reason']}",
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 5),
                    Text("Start Date: ${startDate.toString().substring(0, 10)}"),
                    Text("End Date: ${endDate.toString().substring(0, 10)}"),
                  ],
                ),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      status == 'Approved'
                          ? Icons.check_circle
                          : status == 'Rejected'
                              ? Icons.cancel
                              : Icons.pending,
                      color: status == 'Approved'
                          ? Colors.green
                          : status == 'Rejected'
                              ? Colors.red
                              : Colors.orange,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      status,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: status == 'Approved'
                            ? Colors.green
                            : status == 'Rejected'
                                ? Colors.red
                                : Colors.orange,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    String collectionPath = isStudent ? 'studentleaves' : 'teacherleaves';

    return Scaffold(
      appBar: AppBar(
        title: const Text("Past Leave Applications"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _buildPastLeaves(collectionPath),
      ),
    );
  }
}
