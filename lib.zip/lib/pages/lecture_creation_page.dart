import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:delightful_toast/delight_toast.dart';
import 'package:delightful_toast/toast/components/toast_card.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/pages/attendance_page.dart';
import 'package:notesapp/pages/make_lecture_page.dart';
import 'package:notesapp/services/firestore.dart';

class LectureCreationPage extends StatefulWidget {
  final String teacherId;
  final String courseName;

  LectureCreationPage({super.key, required this.teacherId, required this.courseName});

  @override
  State<LectureCreationPage> createState() => _LectureCreationPageState();
}

class _LectureCreationPageState extends State<LectureCreationPage> {
  final FirestoreService firestoreService = FirestoreService();
  String? division;

  @override
  void initState() {
    super.initState();
    _fetchDivision(); // Fetch division when the widget initializes
  }

  Future<void> _fetchDivision() async {
    try {
      final courseDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(widget.teacherId)
          .collection('courses')
          .doc(widget.courseName)
          .get();

      if (courseDoc.exists && courseDoc.data() != null) {
        setState(() {
          division = courseDoc.data()!['division']; // Extract division field
        });
      } else {
        setState(() {
          division = 'Unknown'; // Fallback if division is not found
        });
      }
    } catch (e) {
      setState(() {
        division = 'Error'; // Handle errors gracefully
      });
    }
  }

  void _deleteLecture(String lectureId) async{
    try{
      await FirebaseFirestore.instance.collection('users').doc('teacheruser')
        .collection('teachers')
        .doc(widget.teacherId)
        .collection('courses')
        .doc(widget.courseName)
        .collection('lectures')
        .doc(lectureId).delete();

        setState(() {
          
        });

        DelightToastBar(builder: (context) => const ToastCard(leading: Icon(Icons.check_box_rounded, color: Colors.green,), title:Text("Lecture deleted successfully ,")),).show(context);
    }catch(e){
      DelightToastBar(builder: (context) => const ToastCard(leading: Icon(Icons.check_box_rounded, color: Colors.green,), title:Text("An error occurred")),).show(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lectures for ${widget.courseName}"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(widget.teacherId)
            .collection('courses')
            .doc(widget.courseName)
            .collection('lectures')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Something went wrong"));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("No lectures created"));
          }
          List<DocumentSnapshot> lectures = snapshot.data!.docs;
          return ListView.builder(
            itemCount: lectures.length,
            itemBuilder: (context, index) {
              final data = lectures[index].data() as Map<String, dynamic>;
              return Padding(
                padding: EdgeInsets.all(8),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 194, 228, 255),
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        spreadRadius: 1,
                        blurRadius: 10,
                        color: const Color.fromARGB(255, 174, 173, 173)
                      )
                    ]
                  ),
                  child: ListTile(
                    title: Text(data['sessionName']),
                    subtitle: Text("Date: ${data['date'].toDate()}"),
                    trailing: IconButton(onPressed:(){_deleteLecture(lectures[index].id);} ,icon: Icon(Icons.delete) ),
                    onTap: () {
                      if (division != null && division != 'Unknown' && division != 'Error') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AttendancePage(
                              teacherId: widget.teacherId,
                              courseName: widget.courseName,
                              lectureId: lectures[index].id,
                              division: division!,
                            ),
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Division not available")),
                        );
                      }
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => MakeLecturePage(
                teacherId: widget.teacherId,
                courseName: widget.courseName,
              ),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
