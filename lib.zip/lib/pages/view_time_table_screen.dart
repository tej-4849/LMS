import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class ViewTimetableScreen extends StatefulWidget {
  @override
  _ViewTimetableScreenState createState() => _ViewTimetableScreenState();
}

class _ViewTimetableScreenState extends State<ViewTimetableScreen> {
  String? selectedYear;
  String? selectedDivision;
  Map<String, dynamic>? timetableData;
  bool isLoading = false;

  // Correct order of days
  final List<String> daysOrder = [
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
  ];


Future<void> fetchTimetable() async {
  if (selectedYear == null || selectedDivision == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Please select both Year and Division"),
        backgroundColor: Colors.red,
      ),
    );
    return;
  }

  setState(() {
    isLoading = true;
    timetableData = null;
  });

  try {
    DocumentSnapshot doc = await FirebaseFirestore.instance
        .collection('users')
        .doc('hod')
        .collection('timetables')
        .doc(selectedYear)
        .collection('divisions')
        .doc(selectedDivision)
        .get();

    if (doc.exists) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>? ?? {};

      // ✅ Simplified sorting (since time is already in 24-hour format)
      Map<String, dynamic> sortedTimetable = {};
      for (String day in daysOrder) {
        if (data['timetable']?.containsKey(day) == true) {
          Map<String, dynamic> dayData = Map.from(data['timetable'][day]);

          // Sort time slots (no need for conversion)
          List<String> sortedTimes = dayData.keys.toList()..sort();

          // Reconstruct sorted day data
          Map<String, dynamic> sortedDayData = {
            for (String time in sortedTimes) time: dayData[time]
          };

          sortedTimetable[day] = sortedDayData;
        }
      }

      setState(() {
        timetableData = {'timetable': sortedTimetable};
      });
    } else {
      setState(() {
        timetableData = {};
      });
    }
  } catch (e) {
    print("Error fetching timetable: $e");
  }

  setState(() {
    isLoading = false;
  });
}






  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text("View Timetable", style: TextStyle(fontWeight: FontWeight.bold)),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueAccent, Colors.lightBlue],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Dropdown Section inside Card
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    buildDropdown("Select Year", selectedYear, ["1st Year", "2nd Year", "3rd Year", "4th Year"],
                        (value) => setState(() => selectedYear = value)),
                    SizedBox(height: 10),
                    buildDropdown("Select Division", selectedDivision, ["A", "B", "C", "D"],
                        (value) => setState(() => selectedDivision = value)),
                    SizedBox(height: 15),
                    ElevatedButton(
                      onPressed: fetchTimetable,
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        backgroundColor: Colors.blueAccent,
                      ),
                      child: Text("Show Timetable", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),

            // Timetable Data
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : timetableData == null
                      ? buildMessage("Select Year & Division and click 'Show Timetable'")
                      : timetableData!.isEmpty
                          ? buildMessage("No timetable found")
                          : buildTimetableTable(),
            ),
          ],
        ),
      ),
    );
  }

  // 🔹 Dropdown Widget
  Widget buildDropdown(String hint, String? value, List<String> items, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        filled: true,
        fillColor: Colors.white,
      ),
      items: items.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
      onChanged: onChanged,
    );
  }

  // 🔹 Message Display Widget
  Widget buildMessage(String text) {
    return Center(
      child: Text(
        text,
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.grey[700]),
        textAlign: TextAlign.center,
      ),
    );
  }

  // 🔹 Timetable Table Widget
  Widget buildTimetableTable() {
    return Container(
      width: double.infinity,
      child: Card(
        margin: EdgeInsets.symmetric(horizontal: 5),
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(
              dataRowMinHeight: 100,
              dataRowMaxHeight: 150,
              headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[200]!),
              dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
              border: TableBorder.all(color: Colors.blueAccent),
              columnSpacing: 20.0,
              columns: [
                DataColumn(label: Text("Day", style: headerStyle)),
                DataColumn(label: Text("Time", style: headerStyle)),
                DataColumn(label: Text("Subject", style: headerStyle)),
                DataColumn(label: Text("Faculty", style: headerStyle)),
              ],
              rows: timetableData!['timetable'].entries.map<DataRow>((dayEntry) {
                String day = dayEntry.key;
                Map<String, dynamic> dayData = dayEntry.value;

                // Time slots are now correctly sorted!
                List<String> sortedTimes = dayData.keys.toList();
                List<String> sortedSubjects = sortedTimes.map((time) => dayData[time]['subject'].toString()).toList();
                List<String> sortedFaculty = sortedTimes.map((time) => dayData[time]['faculty'].toString()).toList();

                return DataRow(
                  cells: [
                    DataCell(Text(day, style: cellStyle)),
                    DataCell(buildColumn(sortedTimes)),
                    DataCell(buildColumn(sortedSubjects)),
                    DataCell(buildColumn(sortedFaculty)),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }

  // 🔹 Helper Function to Build Column Inside Cell
  Widget buildColumn(List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items.map((e) => Padding(padding: EdgeInsets.symmetric(vertical: 2), child: Text(e, style: cellStyle))).toList(),
    );
  }

  // 🔹 Styling for Table Headers
  TextStyle get headerStyle => TextStyle(fontWeight: FontWeight.bold, fontSize: 16);

  // 🔹 Styling for Table Cells
  TextStyle get cellStyle => TextStyle(fontSize: 14, fontWeight: FontWeight.w500);
}
