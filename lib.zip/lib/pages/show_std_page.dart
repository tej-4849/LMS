import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/elements/my_user_listview.dart';
import 'package:notesapp/services/firestore.dart';

class ShowStdPage extends StatefulWidget {
  const ShowStdPage({super.key});

  @override
  State<ShowStdPage> createState() => _ShowStdPageState();
}

class _ShowStdPageState extends State<ShowStdPage> {

  final FirestoreService firestoreService = FirestoreService();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Students' List"),
      ),

      body: StreamBuilder<QuerySnapshot>(
        stream: firestoreService.getStudentStream(), 
        builder: (context, snapshot){
          if(snapshot.hasData){
            if(snapshot.connectionState == ConnectionState.waiting){
               return Center(child: CircularProgressIndicator(),);
            }
            if(snapshot.hasError) return Center(child: Text("Some error occured...."),);
            if(!snapshot.hasData || snapshot.data!.docs.isEmpty) return Center(child: Text("No Student data found"),);

            List studentList = snapshot.data!.docs;
            
            return ListView.builder(
              itemCount: studentList.length,
              itemBuilder: (context, index){
                DocumentSnapshot document = studentList[index];
                Map<String, dynamic> studentMappedData = document.data() as Map<String, dynamic>;

                return MyUserListview(name: studentMappedData['name'], email: studentMappedData['email'], password: studentMappedData['email'], prn: studentMappedData['prn'], year: studentMappedData['year'], division: studentMappedData['division'],);
              });
          }
          else{
            return Center(child: Text("No data found"),);
          }
        }),
    );
  }
}