import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HodLeaveViewPage extends StatelessWidget {
  const HodLeaveViewPage({super.key});

  Future<void> _updateStatus(
      String collection, String docId, String status) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc('hod')
        .collection('leaves')
        .doc(collection)
        .collection(collection)
        .doc(docId)
        .update({'status': status});
  }

  Widget _buildLeaveList(String collection) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc('hod')
          .collection('leaves')
          .doc(collection)
          .collection(collection)
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(child: Text("No leave applications found."));
        }

        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            var leave = snapshot.data!.docs[index];
            var docId = leave.id;

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: ListTile(
                title: Text("${leave['name']} (${leave['userId']})"),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Reason: ${leave['reason']}"),
                    Text(
                        "Dates: ${leave['startDate'].toDate().toString().substring(0, 10)} - ${leave['endDate'].toDate().toString().substring(0, 10)}"),
                    Text("Status: ${leave['status']}"),
                  ],
                ),
                trailing: leave['status'] == 'Pending'
                    ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            onPressed: () => _updateStatus(collection, docId, 'Approved'),
                            icon: Icon(Icons.check, color: Colors.green),
                          ),
                          IconButton(
                            onPressed: () => _updateStatus(collection, docId, 'Rejected'),
                            icon: Icon(Icons.cancel, color: Colors.red),
                          ),
                        ],
                      )
                    : null,
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text("Leave Applications"),
          bottom: TabBar(
            tabs: [
              Tab(text: "Student Leaves"),
              Tab(text: "Teacher Leaves"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildLeaveList('studentleaves'),
            _buildLeaveList('teacherleaves'),
          ],
        ),
      ),
    );
  }
}
