import 'package:flutter/material.dart';
import 'package:notesapp/services/firestore.dart';

class MakeLecturePage extends StatefulWidget {
  final String teacherId;
  final String courseName;

  MakeLecturePage({super.key, required this.teacherId, required this.courseName});

  @override
  State<MakeLecturePage> createState() => _MakeLecturePageState();
}

class _MakeLecturePageState extends State<MakeLecturePage> {
  final FirestoreService firestoreService = FirestoreService();
  final TextEditingController sessionController = TextEditingController();
  DateTime? startTime;
  DateTime? endTime;
  DateTime? lectureDate;

  void submitLecture() async {
    if (sessionController.text.isEmpty || startTime == null || endTime == null || lectureDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please fill all fields")));
      return;
    }

    // Debug: Print the values before submitting
    print("Session Name: ${sessionController.text}");
    print("Start Time: $startTime");
    print("End Time: $endTime");
    print("Lecture Date: $lectureDate");

    try {
      // Create lecture in Firestore
      await firestoreService.createLecture(
        teacherId: widget.teacherId,
        courseName: widget.courseName,
        sessionName: sessionController.text,
        startTime: startTime!,
        endTime: endTime!,
        date: lectureDate!,
      );

      // Navigate back on successful submission
      Navigator.pop(context);
    } catch (e) {
      print("Error creating lecture: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to create lecture")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Create Lecture"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Session Name",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.black),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: sessionController,
                decoration: InputDecoration(
                  labelText: "Enter Session Name",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.blueAccent),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent, width: 2),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Pick Date
              Text(
                "Lecture Date",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.black),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: () async {
                  final pickedDate = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );

                  if (pickedDate != null) {
                    setState(() {
                      lectureDate = pickedDate;
                    });
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  lectureDate != null
                      ? "${lectureDate!.toLocal()}".split(' ')[0]
                      : "Select Date",
                  style: TextStyle(color: Colors.white),
                ),
              ),
              const SizedBox(height: 20),

              // Pick Start Time
              Text(
                "Start Time",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.black),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: () async {
                  final pickedTime = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.now(),
                  );

                  if (pickedTime != null) {
                    setState(() {
                      startTime = DateTime(
                        lectureDate!.year,
                        lectureDate!.month,
                        lectureDate!.day,
                        pickedTime.hour,
                        pickedTime.minute,
                      );
                    });
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  startTime != null
                      ? "${startTime!.hour}:${startTime!.minute < 10 ? '0' : ''}${startTime!.minute}"
                      : "Pick Start Time",
                  style: TextStyle(color: Colors.white),
                ),
              ),
              const SizedBox(height: 20),

              // Pick End Time
              Text(
                "End Time",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.black),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: () async {
                  final pickedTime = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.now(),
                  );

                  if (pickedTime != null) {
                    setState(() {
                      endTime = DateTime(
                        lectureDate!.year,
                        lectureDate!.month,
                        lectureDate!.day,
                        pickedTime.hour,
                        pickedTime.minute,
                      );
                    });
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  endTime != null
                      ? "${endTime!.hour}:${endTime!.minute < 10 ? '0' : ''}${endTime!.minute}"
                      : "Pick End Time",
                  style: TextStyle(color: Colors.white),
                ),
              ),
              const SizedBox(height: 30),

              // Submit Button
              Center(
                child: ElevatedButton(
                  onPressed: submitLecture,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(
                    "Submit",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
