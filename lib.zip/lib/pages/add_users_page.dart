import 'package:flutter/material.dart';
import 'package:notesapp/elements/my_textfield.dart';
import 'package:notesapp/services/firestore.dart';

class AddUsersPage extends StatefulWidget {
  const AddUsersPage({super.key});

  @override
  State<AddUsersPage> createState() => _AddUsersPageState();
}

class _AddUsersPageState extends State<AddUsersPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController stdnameController = TextEditingController();
  final TextEditingController stdemailController = TextEditingController();
  final TextEditingController stdpasswordController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();
  final TextEditingController prnController = TextEditingController();
  final TextEditingController divisionController = TextEditingController();
  final TextEditingController yearController = TextEditingController();

  final TextStyle generalTextStyle =
      TextStyle(fontSize: 20, fontWeight: FontWeight.bold);
  final TextStyle buttonTextStyle =
      TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white);

  final FirestoreService firestoreService = FirestoreService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Create Users"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(bottom: 20, top: 10),
              width: double.infinity,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: const Color.fromARGB(255, 203, 203, 203)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Add Teacher",
                    style: generalTextStyle,
                  ),
                  MyTextfield(
                    textEditingController: nameController,
                    hintText: "Name",
                  ),
                  MyTextfield(
                    textEditingController: emailController,
                    hintText: "Email",
                  ),
                  MyTextfield(
                    textEditingController: passwordController,
                    hintText: "Password",
                  ),
                  MyTextfield(
                    textEditingController: subjectController,
                    hintText: "Subject",
                  ),
                  GestureDetector(
                    onTap: () {
                      firestoreService.addTeacherUser(nameController.text, emailController.text, passwordController.text, subjectController.text);
          
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Teacher added successfully!")),
                      );
          
                      nameController.clear();
                      emailController.clear();
                      passwordController.clear();
                      subjectController.clear();
                    },
                    child: Container(
                      height: 60,
                      width: 100,
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Center(
                          child: Text(
                        "SUBMIT",
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      )),
                    ),
                  )
                ],
              ),
            ),
          
            // container to add the student
          
            const SizedBox(
              height: 50,
            ),
          
            Container(
              padding: EdgeInsets.only(bottom: 20, top: 10),
              width: double.infinity,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: const Color.fromARGB(255, 203, 203, 203)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Add Student",
                    style: generalTextStyle,
                  ),
                  MyTextfield(
                    textEditingController: stdnameController,
                    hintText: "Name",
                  ),
                  MyTextfield(
                    textEditingController: stdemailController,
                    hintText: "Email",
                  ),
                  MyTextfield(
                    textEditingController: stdpasswordController,
                    hintText: "Password",
                  ),
                  MyTextfield(
                    textEditingController: prnController,
                    hintText: "PRN",
                  ),
                  MyTextfield(
                    textEditingController: divisionController,
                    hintText: "Division",
                  ),
                  MyTextfield(
                    textEditingController: yearController,
                    hintText: "Year",
                  ),
                  GestureDetector(
                    onTap: () {
                      firestoreService.addStudent(
                        stdnameController.text,
                        stdemailController.text,
                        stdpasswordController.text,
                        prnController.text,
                        divisionController.text,
                        yearController.text
                      );
          
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Student added successfully!")),
                      );
          
                      stdnameController.clear();
                      stdemailController.clear();
                      stdpasswordController.clear();
                      prnController.clear();
                      divisionController.clear();
                      yearController.clear();
                    },
                    child: Container(
                      height: 60,
                      width: 100,
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Center(
                          child: Text(
                        "SUBMIT",
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      )),
                    ),
                  )
                ],
              ),
            )
          ],
              ),
        ),
      ),
    ); // Container to add teacher

        
  }
}
