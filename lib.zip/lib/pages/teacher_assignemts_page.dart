import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:notesapp/pages/assignment_detail_page.dart';

class TeacherAssignmentsPage extends StatefulWidget {
  final String teacherId;

  TeacherAssignmentsPage({required this.teacherId});

  @override
  _TeacherAssignmentsPageState createState() => _TeacherAssignmentsPageState();
}

class _TeacherAssignmentsPageState extends State<TeacherAssignmentsPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Function to Create a New Assignment
  Future<void> _createAssignment() async {
    TextEditingController assignmentController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Create New Assignment"),
          content: TextField(
            controller: assignmentController,
            decoration: InputDecoration(hintText: "Enter assignment name"),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel"),
            ),
            TextButton(
              onPressed: () async {
                String taskName = assignmentController.text.trim();
                if (taskName.isNotEmpty) {
                  await _firestore
                      .collection('users')
                      .doc('teacheruser')
                      .collection('teachers')
                      .doc(widget.teacherId)
                      .collection('assignments')
                      .add({
                    'taskName': taskName,
                    'createdBy': widget.teacherId,
                    'timestamp': Timestamp.now(),
                  });

                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Assignment Created!")));
                }
                Navigator.pop(context);
              },
              child: Text("Create"),
            ),
          ],
        );
      },
    );
  }

  // Build UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Assignments", style: TextStyle(color: Colors.white),),
        backgroundColor: const Color.fromARGB(255, 19, 162, 238),),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 15),
        child: StreamBuilder(
          stream: _firestore
              .collection('users')
              .doc('teacheruser')
              .collection('teachers')
              .doc(widget.teacherId)
              .collection('assignments')
              .orderBy('timestamp', descending: true)
              .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }
        
            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return Center(child: Text("No task created"));
            }
        
            return ListView(
              children: snapshot.data!.docs.map((doc) {
                return Container(
                  width: double.infinity,
                  height: 100,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 0, 35, 116),
                    borderRadius: BorderRadius.circular(15),
                  ) ,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ListTile(
                      title: Text(doc['taskName'], style: TextStyle(color: Colors.white),),
                      subtitle: Text("Created by: ${doc['createdBy']}", style: TextStyle(color: const Color.fromARGB(255, 215, 215, 215))),
                      trailing: Icon(Icons.arrow_forward_ios, color: Colors.white,),
                      onTap: () {
                        // Navigate to Assignment Detail Page (Next Step)
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AssignmentDetailPage(
                              teacherId: widget.teacherId,
                              assignmentId: doc.id,
                              assignmentName: doc['taskName'],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _createAssignment,
        child: Icon(Icons.add),
      ),
    );
  }
}
