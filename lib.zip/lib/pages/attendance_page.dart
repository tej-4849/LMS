import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/services/firestore.dart';

class AttendancePage extends StatefulWidget {
  final String teacherId;
  final String courseName;
  final String lectureId;
  final String division; // Pass division for filtering students

  AttendancePage({
    super.key,
    required this.teacherId,
    required this.courseName,
    required this.lectureId,
    required this.division,
  });

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  final FirestoreService firestoreService = FirestoreService();

  Map<String, String> attendanceStatus = {};
  Map<String, double> averageAttendance = {}; // Average attendance for each student

  @override
  void initState() {
    super.initState();
    _fetchAttendance();
    _calculateAverageAttendance();
  }

  void _fetchAttendance() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc('teacheruser')
        .collection('teachers')
        .doc(widget.teacherId)
        .collection('courses')
        .doc(widget.courseName)
        .collection('lectures')
        .doc(widget.lectureId)
        .collection('attendance')
        .get();

    setState(() {
      attendanceStatus = {
        for (var doc in snapshot.docs) doc.id: doc['status'] as String,
      };
    });
  }

  Future<void> _calculateAverageAttendance() async {
    try {
      // Fetch all lectures for the course
      final lecturesSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(widget.teacherId)
          .collection('courses')
          .doc(widget.courseName)
          .collection('lectures')
          .get();

      final lectures = lecturesSnapshot.docs;

      if (lectures.isEmpty) return;

      // Initialize counters for each student
      Map<String, int> presentCounts = {};
      for (var lecture in lectures) {
        final attendanceSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(widget.teacherId)
            .collection('courses')
            .doc(widget.courseName)
            .collection('lectures')
            .doc(lecture.id)
            .collection('attendance')
            .get();

        for (var doc in attendanceSnapshot.docs) {
          if (doc['status'] == 'Present') {
            presentCounts[doc.id] = (presentCounts[doc.id] ?? 0) + 1;
          }
        }
      }

      // Calculate average attendance for each student
      Map<String, double> averages = {};
      for (var entry in presentCounts.entries) {
        averages[entry.key] =
            (entry.value / lectures.length) * 100; // Convert to percentage
      }

      setState(() {
        averageAttendance = averages;
      });
    } catch (e) {
      print("Error calculating average attendance: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Attendance for ${widget.courseName}"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('studentuser')
            .collection('students')
            .where('division', isEqualTo: widget.division) // Filter students by division
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Something went wrong"));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("No students found in division ${widget.division}"));
          }

          List<DocumentSnapshot> students = snapshot.data!.docs;

          return ListView.builder(
            itemCount: students.length,
            itemBuilder: (context, index) {
              final student = students[index];
              final studentData = student.data() as Map<String, dynamic>;
              final studentId = student.id;
              final average = averageAttendance[studentId] ?? 0.0; // Default to 0%

              return Container(
                
                child: Padding(//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: (average<=50 )? const Color.fromARGB(255, 255, 172, 166) :(average<75 && average >50)? const Color.fromARGB(255, 255, 247, 176) : const Color.fromARGB(255, 177, 216, 178),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    
                    child: ListTile(
                      
                      title: Text(studentData['name']),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("PRN: ${studentData['prn']}"),
                          Text(
                            "Avg: ${average.toStringAsFixed(1)}%",
                            style: TextStyle(
                              color: Colors.blue),
                          ),
                        ],
                      ),
                      trailing: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: attendanceStatus[studentId] == 'Present'
                                        ? Colors.green
                                        : Colors.grey),
                                onPressed: () {
                                  setState(() {
                                    attendanceStatus[studentId] = 'Present';
                                  });
                                  firestoreService.markAttendance(
                                    teacherId: widget.teacherId,
                                    courseName: widget.courseName,
                                    lectureId: widget.lectureId,
                                    studentId: student.id,
                                    attendanceStatus: 'Present',
                                  );
                                },
                                child: Text(
                                  "Present",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              SizedBox(width: 10),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: (attendanceStatus[studentId] == 'Absent')
                                      ? Colors.red
                                      : Colors.grey,
                                ),
                                onPressed: () {
                                  setState(() {
                                    attendanceStatus[studentId] = 'Absent';
                                  });
                                  firestoreService.markAttendance(
                                    teacherId: widget.teacherId,
                                    courseName: widget.courseName,
                                    lectureId: widget.lectureId,
                                    studentId: student.id,
                                    attendanceStatus: 'Absent',
                                  );
                                },
                                child: Text("Absent", style: TextStyle(color: Colors.white)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
