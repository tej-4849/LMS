import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  // get collection of users
  final CollectionReference users = FirebaseFirestore.instance.collection('users');

  // create a colletion for teacher.
  final CollectionReference teachers = FirebaseFirestore.instance.collection('users').doc('teacheruser').collection('teachers');

  // creating the collection for students
  final CollectionReference students = FirebaseFirestore.instance.collection('users').doc('studentuser').collection('students');

  // getting the collection of the HOD, The king, the Randa
  final DocumentReference hod = FirebaseFirestore.instance.collection('users').doc('hod');

  // get hod data

  Future<DocumentSnapshot> getHodData() async {
    return hod.get();
  }

  // create teacher
  Future<void> addTeacherUser(String name, String email, String password, String subject){
    return teachers.add({
      'name':name,
      'email':email,
      'password':password,
      'subject':subject,
      'role':'teacher',
      'timestamp':Timestamp.now(),
    });
  }

  // create student
  Future<void> addStudent(String name, String email, String password, String prn, String division, String year){
    return students.add({
      'name':name,
      'email':email,
      'password':password,
      'prn':prn,
      'year':year,
      'division':division,
      'role':'student',
      'timestamp':Timestamp.now()
    });
  }

  //read teachers
  Stream<QuerySnapshot> getTeacherStream(){
    final teacherStream = teachers.orderBy('timestamp', descending: true).snapshots();
    return teacherStream;
  }

  //read students
  Stream<QuerySnapshot> getStudentStream(){
    final studentStream = students.orderBy('timestamp').snapshots();
    return studentStream;
  }

  // read teachers wrt the subject
  Stream<QuerySnapshot> getTeacherBySubjectStream(String subject){
    final teacherBySubjectStream = teachers.where('subject', isEqualTo: subject).snapshots();
    return teacherBySubjectStream;
  }

  // read stuudent wrt the division
  Stream<QuerySnapshot> getStudentByDivStream(String division){
    final studentByDivStream = students.where('division', isEqualTo: division).snapshots();
    return studentByDivStream;
  }


  


  //update

  // Future<void> updateNote(String docId, String newNote){
  //   return notes.doc(docId).update({
  //     'note':newNote,
  //     'timestamp':Timestamp.now()
  //   });
  // }
  
  // //delete
  // Future<void> deleteNode(String docId){
  //   return notes.doc(docId).delete();
  // }

  // final CollectionReference sarvNotes = FirebaseFirestore.instance.collection('notes').doc('Sarvesh').collection('sarvNotes');


  // Future<void> addSarvNote(String note){
  //   return sarvNotes.add({
  //     'note':note,
  //     'timestamp':Timestamp.now()
  //   });
  // }

  // Stream<QuerySnapshot> getSarvNoteStream(){
  //   final sarvNotesStream = sarvNotes.orderBy('timestamp', descending: true).snapshots();
  //   return sarvNotesStream;
  // }

  // Future<void> updateSarvNote(String docId, String newNote){
  //   return sarvNotes.doc(docId).update({
  //     'note':newNote,
  //     'timestamp':Timestamp.now()
  //   });
  // }

  // Future<void> deleteSarvNote(String docId){
  //   return sarvNotes.doc(docId).delete();
  // }

}