import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FirestoreService {
  // get collection of users
  final CollectionReference users = FirebaseFirestore.instance.collection('users');

  // create a colletion for teacher.
  final CollectionReference teachers = FirebaseFirestore.instance.collection('users').doc('teacheruser').collection('teachers');

  // creating the collection for students
  final CollectionReference students = FirebaseFirestore.instance.collection('users').doc('studentuser').collection('students');

  // getting the collection of the HOD, The king, the Randa
  final DocumentReference hod = FirebaseFirestore.instance.collection('users').doc('hod');

  // get hod data

  Future<DocumentSnapshot> getHodData() async {
    return hod.get();
  }

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addTeacherUser(
    String name,
    String email,
    String password,
    String subject,
    String imageUrl,
  ) async {
    await _firestore
        .collection("users")
        .doc("teacheruser")
        .collection("teachers")
        .add({
      "name": name,
      "email": email,
      "password": password,
      "subject": subject,
      "imageUrl": imageUrl,
      "timestamp": FieldValue.serverTimestamp(),
    });
  }

  Future<void> addStudent(String name, String email, String password, String prn, String division, String year, String profileImage) async {
  await FirebaseFirestore.instance.collection('users').doc('studentuser').collection('students').add({
    'name': name,
    'email': email,
    'password': password,
    'prn': prn,
    'division': division,
    'year': year,
    'profileImage': profileImage, // 👈 THIS LINE is critical
    'timestamp': FieldValue.serverTimestamp(),
  });
}

  //read teachers
  Stream<QuerySnapshot> getTeacherStream(){
    final teacherStream = teachers.orderBy('timestamp', descending: true).snapshots();
    return teacherStream;
  }

  void debugTestTeachers() async {
  QuerySnapshot snapshot = await teachers.get();
  if (snapshot.docs.isNotEmpty) {
    for (var doc in snapshot.docs) {
      print("Teacher: ${doc.id}, Data: ${doc.data()}");
    }
  } else {
    print("No teachers found.");
  }
}

  //read students
  Stream<QuerySnapshot> getStudentStream(){
    final studentStream = students.orderBy('timestamp', descending: true).snapshots();
    return studentStream;
  }

  // read teachers wrt the subject
  Stream<QuerySnapshot> getTeacherBySubjectStream(String subject){
    final teacherBySubjectStream = teachers.where('subject', isEqualTo: subject).snapshots();
    return teacherBySubjectStream;
  }

  // read stuudent wrt the division
  Stream<QuerySnapshot> getStudentByDivStream(String division){
    final studentByDivStream = students.where('division', isEqualTo: division).snapshots();
    return studentByDivStream;
  }

  // login shit

  Future<Map<String, dynamic>> login(String email, String password, String role) async {
  try {
    if (role  == 'hod') {
      // Handle HOD login separately
      final hodDoc = await FirebaseFirestore.instance.collection('users').doc('hod').get();

      if (!hodDoc.exists) {
        print("HOD document not found");
        throw Exception("Invalid email or password");
      }

      final hodData = hodDoc.data();

      if (hodData?['email'] == email && hodData?['password'] == password) {
        final mappedHodData = {'id': 'hod', ...hodData!};
        print("Sending the HOD: $mappedHodData");
        return mappedHodData;
      } else {
        throw Exception("Invalid email or password");
      }
    } else {
      // Handle teacheruser/studentuser login
      final subcollection = (role == 'teacheruser') ? 'teachers' : 'students';
      final query = await FirebaseFirestore.instance
          .collection('users')
          .doc(role)
          .collection(subcollection)
          .where('email', isEqualTo: email)
          .where('password', isEqualTo: password)
          .get();

      if (query.docs.isEmpty) {
        print("No user found with this email: $email");
        throw Exception("Invalid email or password");
      }

      final doc = query.docs.first;
      final mappedUserData = {'id': doc.id, ...doc.data()};
      print("Sending the user: $mappedUserData");
      return mappedUserData;
    }
  } catch (e) {
    print("Error in login: $e");
    throw Exception("Invalid credentials or error occurred");
  }
}


  // teacher course creation
  Future<void> createCourse({required String teacherId, required String courseName, required String division}) async{
    try{
      // get the reference to the teacher creating the course
      final DocumentReference teacherDocRef = FirebaseFirestore.instance.collection('users').doc('teacheruser').collection('teachers').doc(teacherId);

      // adding the course under that teacher

      final coursesCollection = teacherDocRef.collection('courses').doc(courseName);

      await coursesCollection.set({
        'courseName':courseName,
        'division':division,
        'timestamp':Timestamp.now()
      });

      print('Document created successfully');
    }catch(e){
      print('Error creating the course: $e');
      throw Exception("Could Not create course");
    }
  }

  // getting the created course collection
  Stream<QuerySnapshot> getCoursesList(String teacherId){
    print("Teacher ID:$teacherId");
    final showCourseCollection = FirebaseFirestore.instance.collection('users').doc('teacheruser').collection('teachers').doc(teacherId).collection('courses').snapshots();

    showCourseCollection.listen((snapshot){
      if(snapshot.docs.isEmpty){
        print('no courses found nigg for this teacher');

      }else{
        for(var doc in snapshot.docs){
          print("course: ${doc.id}, Data: ${doc.data()}");
        }
      }
    });
    return showCourseCollection;
  }

  // creating a lecture
  Future<void> createLecture({
    required String teacherId,
    required String courseName,
    required String sessionName,
    required DateTime startTime,
    required DateTime endTime,
    required DateTime date,
  }) async {
    final courseRef = FirebaseFirestore.instance.collection('users').doc('teacheruser').collection('teachers').doc(teacherId).collection('courses').doc(courseName).collection('lectures');

    await courseRef.add({
      'sessionName': sessionName,
      'startTime': Timestamp.fromDate(startTime),
      'endTime': Timestamp.fromDate(endTime),
      'date': Timestamp.fromDate(date),
      'timestamp': Timestamp.now(),
    });
  }

  void markAttendance({
    required String teacherId,
    required String courseName,
    required String lectureId,
    required String studentId,
    required String attendanceStatus,
  }) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(teacherId)
          .collection('courses')
          .doc(courseName)
          .collection('lectures')
          .doc(lectureId)
          .collection('attendance')
          .doc(studentId)
          .set({
        'studentId': studentId,
        'status': attendanceStatus,
        'timestamp': FieldValue.serverTimestamp(),
      });
      print("Attendance marked: $attendanceStatus for student: $studentId");
    } catch (e) {
      print("Error marking attendance: $e");
    }
  }

  // creating timetable by hod

  Future<void> createTimeTable({
    required String division,
    required String year,
    required String time,
    required String subject,
    required String day,
    required List<Map<String, dynamic>> schedule,
    
  }) async {
    try{
      await FirebaseFirestore.instance
      .collection('users')
      .doc('hod')
      .collection('timetables')
      .doc(year)
      .collection('divisions')
      .doc(division)
      .collection('days')
      .doc(day)
      .set({
        'subject' : subject,
        'time' : time,
        'timestamp' : Timestamp.now()
      });

      print('TimeTable created successfully');
    }catch (e){
      print("Error createing the timetables: $e");
    }
  }

  // fetching timetable by hod
  Future<List<Map<String, dynamic>>?> fetchTimeTable(String year, String divison) async{
    try{
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('users')
      .doc('hod')
      .collection('timetables')
      .doc(year)
      .collection('divisions')
      .doc(divison)
      .collection('days')
      .get();

      if(querySnapshot.docs.isNotEmpty){
        List<Map<String, dynamic>> timeTable =  querySnapshot.docs.map((doc){
          return {
            "day" : doc.id,
            "subjects" :  doc['subjects'] ?? []
          };
        }).toList();
        return timeTable;
      }else{
        print("No timetable found for $year - $divison");
        return null;
      }

    }catch(e){
      print("Error fetching timetable: $e");
      return null;
    }
  }

  // deleting timetable by the hod
  Future<void> deleteTimeTable(String year, String division) async{
    try{
      CollectionReference daysCollection = await FirebaseFirestore.instance
      .collection('users')
      .doc('hod')
      .collection('timetables')
      .doc(year)
      .collection('divisions')
      .doc(division)
      .collection('days');
      
      QuerySnapshot querySnapshot = await daysCollection.get();
      for(var doc in querySnapshot.docs){
        await doc.reference.delete();
      }

      print('TImetable deleted for $year - $division');
    }
    catch(e){
      print('Error deleting timetable $e');
    }
  }
  // updating timetable by hod
  Future<void> updateTimeTable({
    required String year,
    required String division,
    required String day,
    required List<Map<String, dynamic>> updatedSchedule,
  }) async{
    try{
      DocumentReference  dayDocRef = FirebaseFirestore.instance
      .collection('users')
      .doc('hod')
      .collection('timetables')
      .doc(year)
      .collection('divisions')
      .doc(division)
      .collection('days')
      .doc(day);

      await dayDocRef.set({
        'subjects' : updatedSchedule,
        'timestamp' : Timestamp.now()
      }, SetOptions(merge: true)) ;// setoptions ensures only subject field is updated

      print('Timetable updated for $division ($year) on $day');
    }catch (e){
      print("Error updating the timetable : $e");
    }
  }



  


}