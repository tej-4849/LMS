import 'package:flutter/material.dart';

class CourseCompInfo extends StatelessWidget {
  final int number;
  final String status;
  
  CourseCompInfo({required this.number, required this.status,});

  @override
  Widget build(BuildContext context) {
     return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 15.0),
          child: Container(
            height: 150,
            width: 150,
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 216, 216, 216),
              borderRadius: BorderRadius.circular(15)
              
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(number.toString(), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 40, color: const Color.fromARGB(255, 0, 0, 0)),),

                  const SizedBox(height: 10,),
                  Column(
                    children: [
                      Text("Courses", style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold,),),
                      Text(status, style: TextStyle(fontSize: 17,),),
                    ],
                  ),
                  
                  
                ],
              ),
            ),
          ),
        ),

     

        

      ],
    ); 
  }
}