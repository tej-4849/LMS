import 'package:flutter/material.dart';

class ModuleCont extends StatelessWidget {
  final Icon icon;
  final String name;

  ModuleCont({required this.icon, required this.name});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 10.0),
      child: Container(
        height: 120,
        width: 100,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey,
              blurRadius: 7,
              spreadRadius: 1
            )
          ],
          borderRadius: BorderRadius.circular(15)
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
      
          children: [
            Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.blue[100]
              ),
              child: icon,
            ),
      
            Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, ), textAlign: TextAlign.center,)
          ],
        ),
      
      
      ),
    );
  }
}