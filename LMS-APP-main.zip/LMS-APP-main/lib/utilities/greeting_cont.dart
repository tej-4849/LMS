import 'package:flutter/material.dart';
import 'package:notesapp/pages/profile_page_std.dart';

class GreetingCont extends StatelessWidget {
  final Map<String, dynamic> userData; 
  const GreetingCont({super.key, required this.userData});

  @override
  Widget build(BuildContext context) {
    return Container(
              height: 100,
              width: double.infinity,
              decoration: BoxDecoration(
                
              ),

              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Hi, ${userData['name']}", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),),

                      Text("Let's start learning", style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),)
                    ],

                  
                  ),

                  GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> ProfilePage(userData: userData)));
                    }
                    ,
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:Colors.white
                      ),
                      child: Icon(Icons.person),
                      
                    ),
                  )
                ],
              ),
            );
  }
}