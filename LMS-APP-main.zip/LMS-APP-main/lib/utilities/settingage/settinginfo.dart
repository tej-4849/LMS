import 'package:flutter/material.dart';

class Settinginfo extends StatelessWidget {
  const Settinginfo({super.key});

  @override
  Widget build(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: screenHeight/9.5,
                          width: double.infinity,
                          
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: const Color.fromARGB(255, 243, 243, 243),
                          ),
                    
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.amber
                                  ),
                                ),
                                const SizedBox(width: 20,),
                                Text("Sarvesh Kamtekar", style: TextStyle(color: Colors.black, fontSize: 20),)
                              ],
                            ),
                          ),
                        ),


                        
                      ],
                    ),
                  );
  }
}