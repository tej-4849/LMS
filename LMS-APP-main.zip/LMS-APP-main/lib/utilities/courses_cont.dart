import 'package:flutter/material.dart';

class CoursesCont extends StatelessWidget {
  final String name;
  final String teacherName;
  final String short;

  CoursesCont({required this.name, required this.teacherName, required this.short});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 15.0),
          child: Container(
            height: 150,
            width: 150,
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 20, 52, 78),
              borderRadius: BorderRadius.circular(15)
              
            ),
            child: Center(
              child: Text(short, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 35, color: Colors.white),),
            ),
          ),
        ),

        const SizedBox(height: 20,),

        Text(name, style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),),
        Text(teacherName, style: TextStyle(fontSize: 14,),),

      ],
    );
  }
}