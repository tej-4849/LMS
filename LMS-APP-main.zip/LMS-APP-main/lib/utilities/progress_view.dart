import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/pages/student_attendance_show_page.dart';

class ProgressView extends StatelessWidget {
  final Map<String, dynamic> studentData;
  const ProgressView({super.key, required this.studentData});

  Future<Map<String, int>> _getAssignmentStats() async {
    int totalAssignments = 0;
    int submittedAssignments = 0;
    String studentId = studentData['id'];

    final teacherDocs = await FirebaseFirestore.instance
        .collection('users')
        .doc('teacheruser')
        .collection('teachers')
        .get();

    for (var teacher in teacherDocs.docs) {
      final assignmentsSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(teacher.id)
          .collection('assignments')
          .get();

      totalAssignments += assignmentsSnapshot.docs.length;

      for (var assignment in assignmentsSnapshot.docs) {
        final submissionDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(teacher.id)
            .collection('assignments')
            .doc(assignment.id)
            .collection('submissions')
            .doc(studentId)
            .get();

        if (submissionDoc.exists) {
          submittedAssignments += 1;
        }
      }
    }

    return {
      'total': totalAssignments,
      'submitted': submittedAssignments,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 25.0, right: 25),
      child: Container(
        height: 250,
        width: double.infinity,
        decoration: BoxDecoration(
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(blurRadius: 15, spreadRadius: 1, color: Colors.grey)
            ]),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Your Progress",
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black),
              ),
              const SizedBox(
                height: 20,
              ),
              Container(
                height: 80,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 180, 221, 255),
                    borderRadius: BorderRadius.circular(15)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Assignments Submitted",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.center,
                    //   children: [
                    //     Text("0", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red, fontSize: 27),),
                    //     Text("/25", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 27),)
                    //   ],
                    // )

                    FutureBuilder<Map<String, int>>(
                      future: _getAssignmentStats(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return CircularProgressIndicator(
                            color: Colors.white,
                          );
                        }

                        final stats = snapshot.data!;
                        return Row(
                          children: [
                            Text(
                              "${stats['submitted']}",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green,
                                  fontSize: 27),
                            ),
                            Text(
                              "/${stats['total']}",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 27),
                            ),
                          ],
                        );
                      },
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => StudentAttendanceShowPage(
                                  studentId: studentData['id'])));
                    },
                    child: Container(
                      height: 70,
                      width: MediaQuery.of(context).size.width / 2,
                      decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 156, 199, 255),
                          borderRadius: BorderRadius.circular(15)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "Attendance",
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: 70,
                    width: MediaQuery.of(context).size.width / 4,
                    decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 24, 151, 255),
                        borderRadius: BorderRadius.circular(15)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "More",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
