import 'package:flutter/material.dart';

class InncompleteAss extends StatelessWidget {
  
  final String name;
  final int totalAss;
  final int completedAss;

  InncompleteAss({required this.name, required this.completedAss, required this.totalAss});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Container(
                  height: 70,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 66, 120, 255),
                    borderRadius: BorderRadius.circular(15)
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(name, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),),
                        Text("${completedAss.toString()} / ${totalAss.toString()}", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),),
                        
                      ],
                    ),
                  ),
                ),
    );
  }
}