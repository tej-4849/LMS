import 'package:flutter/material.dart';

class MyUserListview extends StatelessWidget {
  final String name;
  final String email;
  final String password;
  final String? subject;
  final String? prn;
  final String? year;
  final String? division;
  final String? imageUrl; // NEW

  final TextStyle infoTextStyle =
      TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white);
  final TextStyle subinfoTextStyle =
      TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white);

  MyUserListview({
    required this.name,
    required this.email,
    required this.password,
    this.subject,
    this.prn,
    this.year,
    this.division,
    this.imageUrl, // NEW
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: const Color.fromARGB(255, 83, 119, 239),
          boxShadow: [
            BoxShadow(
              spreadRadius: 1,
              blurRadius: 5,
              color: Colors.grey.withOpacity(0.5),
            )
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              // Left: Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Name: $name", style: infoTextStyle),
                    Text("Email: $email", style: subinfoTextStyle),
                    Text("Password: $password", style: subinfoTextStyle),
                    if (subject != null)
                      Text("Subject: $subject", style: subinfoTextStyle),
                    if (prn != null) Text("PRN: $prn", style: subinfoTextStyle),
                    if (year != null)
                      Text("Year: $year", style: subinfoTextStyle),
                    if (division != null)
                      Text("Division: $division", style: subinfoTextStyle),
                  ],
                ),
              ),

              // Right: Image
              if (imageUrl != null && imageUrl!.isNotEmpty)
                CircleAvatar(
                  radius: 40,
                  
                  backgroundColor: Colors.grey[300],
                  child: ClipOval(
                    child: imageUrl != null && imageUrl!.isNotEmpty
                        ? Image.network(
                            imageUrl!,
                            fit: BoxFit.cover,
                            width: 80,
                            height: 80,
                            loadingBuilder: (BuildContext context, Widget child,
                                ImageChunkEvent? loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Center(
                                child: SizedBox(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    value: loadingProgress.expectedTotalBytes !=
                                            null
                                        ? loadingProgress
                                                .cumulativeBytesLoaded /
                                            loadingProgress.expectedTotalBytes!
                                        : null,
                                  ),
                                ),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) =>
                                Icon(Icons.person, size: 30),
                          )
                        : Icon(Icons.person, size: 30),
                  ),
                )
              else
                const Icon(Icons.person, size: 80, color: Colors.white70),
            ],
          ),
        ),
      ),
    );
  }
}
