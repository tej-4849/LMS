import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:notesapp/pages/assignment_list_page.dart';

// this is for the students to view the assignment


class ViewAssignmentsPage extends StatelessWidget {
  final String userId;

  ViewAssignmentsPage({
    required this.userId
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("View Assignments", style: TextStyle(color: Colors.white), ), backgroundColor: const Color.fromARGB(255, 4, 56, 89),),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("No assignments available"));
          }

          List<Widget> teacherList = [];

          return FutureBuilder<List<Widget>>(
            future: _fetchTeachersWithAssignments(snapshot.data!.docs, context),
            builder: (context, futureSnapshot) {
              if (!futureSnapshot.hasData) {
                return Center(child: CircularProgressIndicator());
              }

              return ListView(children: futureSnapshot.data!);
            },
          );
        },
      ),
    );
  }

  Future<List<Widget>> _fetchTeachersWithAssignments(List<QueryDocumentSnapshot> teachers, BuildContext context) async {
    List<Widget> teacherList = [];

    for (var teacherDoc in teachers) {
      var assignmentSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(teacherDoc.id)
          .collection('assignments')
          .get();

      if (assignmentSnapshot.docs.isNotEmpty) {
        var teacherData = teacherDoc.data() as Map<String, dynamic>;
        String teacherName = teacherData['name'] ?? "Unknown Teacher";

       teacherList.add(
  Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
    child: Container(
      width: double.infinity,
      height: 100,
      alignment: Alignment.centerLeft, // Aligns text to the left
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 31, 148, 221),
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListTile(
        title: Text(
          teacherName,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          textAlign: TextAlign.start, // Keeps text aligned to the start
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AssignmentListPage(
                teacherId: teacherDoc.id,
                teacherName: teacherName,
                studentId: userId,
              ),
            ),
          );
        },
      ),
    ),
  ),
);

      }
    }

    return teacherList;
  }
}
