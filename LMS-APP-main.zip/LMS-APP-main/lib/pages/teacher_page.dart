import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:delightful_toast/delight_toast.dart';
import 'package:delightful_toast/toast/components/toast_card.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/elements/my_textfield.dart';
import 'package:notesapp/pages/leave_submission_page.dart';
import 'package:notesapp/pages/lecture_session_page.dart';
import 'package:notesapp/pages/past_leaves_page.dart';
import 'package:notesapp/pages/study_material_screen.dart';
import 'package:notesapp/pages/teacher_assignemts_page.dart';
import 'package:notesapp/services/firestore.dart';

class TeacherPage extends StatelessWidget {
  final Map<String, dynamic> userData;
  
  TeacherPage({super.key, required this.userData});

  final FirestoreService firestoreService = FirestoreService();

  final TextEditingController courseController = TextEditingController();
  final TextEditingController divController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Teacher's page"),
        
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
          child: Column(
            children: [
        
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text("Welcome ${userData['name']}", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
        
                  ],
                ),
                const SizedBox(height: 30,),
                
        
                // course creation button
                GestureDetector(
                  onTap: () {
                    showDialog(context: context, builder: (context)=>Dialog(
                     child: Container(
                      height: 400,
                       child: Column(
                        children: [
                          MyTextfield(textEditingController: courseController, hintText: "Course name"),
                          const SizedBox(height: 30,),
                          MyTextfield(textEditingController: divController, hintText: "Enter Division(A,B,C)"),
                          GestureDetector(
                            onTap: (){
                              firestoreService.createCourse(teacherId: userData['id'], courseName: courseController.text, division: divController.text);
                              Navigator.pop(context);
                              DelightToastBar(
                                builder: (context)=> const ToastCard(leading: Icon(Icons.check, color: Colors.green), 
                                title: Text('Course added successfully'),)
                              ).show(context);
                            },
                            child: Container(
                              height: 80,
                              width: 130,
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: const Center(child: Text("SUBMIT",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),),
                            ),
                          )
                          
                          
                        ],
                       ),
                     ), 
                    )
                    );
                  },
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 75, 161, 78),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Create Courses", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),),
                  ),
                ),
              //***************************************************************************** */
        
              const SizedBox(height: 30,),
        
              GestureDetector(
                  onTap: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>LectureSessionPage(teacherData: userData,)));
                  },
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 54, 130, 230),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Lecture Sessions", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),),
                  ),
                ),
        
                const SizedBox(height: 30,),
        
                GestureDetector(
                  onTap: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>LeaveSubmissionPage(isStudent: false, userId: userData['id'], userName: userData['name'])));
                  },
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 54, 130, 230),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Apply for leave", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),),
                  ),
                ),
                const SizedBox(height: 30,),
                GestureDetector(
                  onTap: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>PastLeavesPage(isStudent: false, userId: userData['id'])));
                  },
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 54, 130, 230),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Show past leave applications", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),),
                  ),
                ),
                const SizedBox(height: 30,),
                GestureDetector(
                  onTap: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=> StudyMaterialScreen(teacherId: userData['id'])));
                  },
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 253, 156, 78),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Study Material", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),),
                  ),
                ),

                const SizedBox(
                  height: 30,
                ),

                GestureDetector(
                  onTap: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=> TeacherAssignmentsPage(teacherId: userData['id'])));
                  },
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.blue.shade800,
                      borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Create Assignments", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}