import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ViewTimetableScreen extends StatefulWidget {
  @override
  _ViewTimetableScreenState createState() => _ViewTimetableScreenState();
}

class _ViewTimetableScreenState extends State<ViewTimetableScreen> {
  String? selectedYear;
  String? selectedDivision;
  String? selectedClass;
  Map<String, dynamic>? timetableData;
  bool isLoading = false;

  final List<String> daysOrder = [
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
  ];

  Future<void> fetchTimetable() async {
    if (selectedYear == null || selectedDivision == null || selectedClass == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Please select Year, Division, and Class"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      isLoading = true;
      timetableData = null;
    });

    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('users')
          .doc('hod')
          .collection('timetables')
          .doc(selectedYear)
          .collection('divisions')
          .doc(selectedDivision)
          .collection('classes')
          .doc(selectedClass)
          .get();

      if (doc.exists) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>? ?? {};
        String? className = data['class']; // Get class name from the Firestore document

        Map<String, dynamic> sortedTimetable = {};
        for (String day in daysOrder) {
          if (data['timetable']?.containsKey(day) == true) {
            Map<String, dynamic> dayData = Map.from(data['timetable'][day]);
            List<String> sortedTimes = dayData.keys.toList()..sort();

            Map<String, dynamic> sortedDayData = {
              for (String time in sortedTimes) time: dayData[time]
            };

            sortedTimetable[day] = sortedDayData;
          }
        }

        setState(() {
          timetableData = {'class': className, 'timetable': sortedTimetable};
        });
      } else {
        setState(() {
          timetableData = {};
        });
      }
    } catch (e) {
      print("Error fetching timetable: $e");
    }

    setState(() {
      isLoading = false;
    });
  }

  Future<void> updateTimetable() async {
    if (selectedYear == null || selectedDivision == null || selectedClass == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Please select Year, Division, and Class"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc('hod')
          .collection('timetables')
          .doc(selectedYear)
          .collection('divisions')
          .doc(selectedDivision)
          .collection('classes')
          .doc(selectedClass)
          .set({
        'year': selectedYear,
        'division': selectedDivision,
        'class': selectedClass,
        'timetable': timetableData,
        'timestamp': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Timetable updated successfully!"),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      print("Error updating timetable: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text("View Timetable", style: TextStyle(fontWeight: FontWeight.bold)),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueAccent, Colors.lightBlue],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    buildDropdown("Select Year", selectedYear,
                        ["1st Year", "2nd Year", "3rd Year", "4th Year"],
                        (value) => setState(() => selectedYear = value)),
                    SizedBox(height: 10),
                    buildDropdown("Select Division", selectedDivision,
                        ["A", "B", "C", "D"],
                        (value) => setState(() => selectedDivision = value)),
                    SizedBox(height: 10),
                    buildDropdown("Select Class", selectedClass,
                        ["CSCR01", "CSCR02", "CSCR03", "CSCR04", "CSCR05"],
                        (value) => setState(() => selectedClass = value)),
                    SizedBox(height: 15),
                    ElevatedButton(
                      onPressed: fetchTimetable,
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        backgroundColor: Colors.blueAccent,
                      ),
                      child: Text("Show Timetable", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                    SizedBox(height: 15),
                    ElevatedButton(
                      onPressed: updateTimetable,
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        backgroundColor: Colors.greenAccent,
                      ),
                      child: Text("Update Timetable", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : timetableData == null
                      ? buildMessage("Select Year, Division, and Class and click 'Show Timetable'")
                      : timetableData!.isEmpty
                          ? buildMessage("No timetable found")
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (timetableData?['class'] != null)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 8.0),
                                    child: Text(
                                      "Class: ${timetableData!['class']}",
                                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blueAccent),
                                    ),
                                  ),
                                Expanded(child: buildTimetableTable()),
                              ],
                            ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildDropdown(String hint, String? value, List<String> items, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        filled: true,
        fillColor: Colors.white,
      ),
      items: items.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
      onChanged: onChanged,
    );
  }

  Widget buildMessage(String text) {
    return Center(
      child: Text(
        text,
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.grey[700]),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget buildTimetableTable() {
    return Container(
      width: double.infinity,
      child: Card(
        margin: EdgeInsets.symmetric(horizontal: 5),
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(
              dataRowMinHeight: 100,
              dataRowMaxHeight: 150,
              headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[200]!),
              dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
              border: TableBorder.all(color: Colors.blueAccent),
              columnSpacing: 20.0,
              columns: [
                DataColumn(label: Text("Day", style: headerStyle)),
                DataColumn(label: Text("Time", style: headerStyle)),
                DataColumn(label: Text("Subject", style: headerStyle)),
                DataColumn(label: Text("Faculty", style: headerStyle)),
              ],
              rows: timetableData!['timetable'].entries.map<DataRow>((dayEntry) {
                String day = dayEntry.key;
                Map<String, dynamic> dayData = dayEntry.value;

                List<String> sortedTimes = dayData.keys.toList();
                List<String> sortedSubjects = sortedTimes.map((time) => dayData[time]['subject'].toString()).toList();
                List<String> sortedFaculty = sortedTimes.map((time) => dayData[time]['faculty'].toString()).toList();

                return DataRow(
                  cells: [
                    DataCell(Text(day, style: cellStyle)),
                    DataCell(buildColumn(sortedTimes)),
                    DataCell(buildColumn(sortedSubjects)),
                    DataCell(buildColumn(sortedFaculty)),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildColumn(List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items.map((e) => Padding(padding: EdgeInsets.symmetric(vertical: 2), child: Text(e, style: cellStyle))).toList(),
    );
  }

  TextStyle get headerStyle => TextStyle(fontWeight: FontWeight.bold, fontSize: 16);
  TextStyle get cellStyle => TextStyle(fontSize: 14, fontWeight: FontWeight.w500);
}
