import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class StudentAttendanceShowPage extends StatelessWidget {
  final String studentId;

  StudentAttendanceShowPage({super.key, required this.studentId});

  Future<List<Map<String, dynamic>>> _getAttendanceRecords() async {
    List<Map<String, dynamic>> attendanceRecords = [];

    QuerySnapshot teacherCoursesSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc('teacheruser')
        .collection('teachers')
        .get();

    for (var teacherDoc in teacherCoursesSnapshot.docs) {
      var teacherId = teacherDoc.id;

      QuerySnapshot coursesSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(teacherId)
          .collection('courses')
          .get();

      for (var courseDoc in coursesSnapshot.docs) {
        var courseName = courseDoc.id;

        QuerySnapshot lecturesSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(teacherId)
            .collection('courses')
            .doc(courseName)
            .collection('lectures')
            .get();

        for (var lectureDoc in lecturesSnapshot.docs) {
          var lectureId = lectureDoc.id;
          var sessionName = lectureDoc['sessionName']; // Fetch sessionName

          DocumentSnapshot attendanceSnapshot = await FirebaseFirestore.instance
              .collection('users')
              .doc('teacheruser')
              .collection('teachers')
              .doc(teacherId)
              .collection('courses')
              .doc(courseName)
              .collection('lectures')
              .doc(lectureId)
              .collection('attendance')
              .doc(studentId)
              .get();

          if (attendanceSnapshot.exists) {
            attendanceRecords.add({
              'sessionName': sessionName, // Include sessionName
              'courseName': courseName,
              'teacherId': teacherId,
              'status': attendanceSnapshot['status'],
              'timestamp': attendanceSnapshot['timestamp'].toDate(),
            });
          }
        }
      }
    }
    // Sort records by timestamp in descending order
    attendanceRecords.sort((a, b) => b['timestamp'].compareTo(a['timestamp']));

    return attendanceRecords;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 223, 241, 255),
      appBar: AppBar(
        title: Text("Attendance Records"),
        centerTitle: true,
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _getAttendanceRecords(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("Error fetching attendance"));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Text(
                "No attendance records found.",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            );
          }

          List<Map<String, dynamic>> records = snapshot.data!;

          return ListView.builder(
            itemCount: records.length,
            padding: const EdgeInsets.all(10),
            itemBuilder: (context, index) {
              var record = records[index];
              var status = record['status'];
              var date = DateFormat.yMMMEd().add_jm().format(record['timestamp']);

              return Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Lecture Details
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Course: ${record['courseName']}",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            "Session: ${record['sessionName']}", // Show sessionName
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[700],
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            "Date: $date",
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[700],
                            ),
                          ),
                        ],
                      ),

                      // Attendance Status
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            status == 'Present' ? Icons.check_circle : Icons.cancel,
                            color: status == 'Present' ? Colors.green : Colors.red,
                            size: 30,
                          ),
                          const SizedBox(height: 5),
                          Text(
                            status,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: status == 'Present' ? Colors.green : Colors.red,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
