import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/elements/my_course_listview.dart';
import 'package:notesapp/pages/lecture_creation_page.dart';
import 'package:notesapp/services/firestore.dart';

class LectureSessionPage extends StatefulWidget {
  final Map<String, dynamic> teacherData;
  const LectureSessionPage({super.key, required this.teacherData});

  @override
  State<LectureSessionPage> createState() => _LectureSessionPageState();
}

class _LectureSessionPageState extends State<LectureSessionPage> {
  final FirestoreService firestoreService = FirestoreService();
  
  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: AppBar(
        title: Text("Lecture Selection"),
      ),

      body: StreamBuilder<QuerySnapshot>(
        stream: firestoreService.getCoursesList(widget.teacherData['id']), 
        builder: (context, snapshot){
          if(snapshot.connectionState == ConnectionState.waiting){
            return Center(child: CircularProgressIndicator(),);
          }
          if(snapshot.hasError){
            return Center(child: Text("Something went wrong"));
          }
          if(!snapshot.hasData){
            return Center(child: Text("No data Found"),);
          }
          List courseList = snapshot.data!.docs;
          print(courseList);

          return ListView.builder(
            itemCount: courseList.length,
            itemBuilder: (context, index){
              DocumentSnapshot document = courseList[index];
              final documentId = document.id;
              Map<String, dynamic> mappedCourseData = document.data() as Map<String, dynamic>;
              // Debug print to verify each teacher's data
              print("Mapped Course Data: $mappedCourseData");
              return GestureDetector(
                onTap: (){
                  Navigator.push(context, (MaterialPageRoute(builder: (context)=>LectureCreationPage(teacherId:widget.teacherData['id'] , courseName: mappedCourseData['courseName'],))));
                },
                child: MyCourseListview(courseName: mappedCourseData['courseName'], division: mappedCourseData['division']));
          });

        }),
    );
  }
}