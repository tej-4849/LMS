import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ProofViewerPage extends StatelessWidget {
  final String proofUrl;

  const ProofViewerPage({super.key, required this.proofUrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Proof Document")),
      body: Center(
        child: ElevatedButton.icon(
          onPressed: () async {
            if (await canLaunchUrl(Uri.parse(proofUrl))) {
              await launchUrl(Uri.parse(proofUrl), mode: LaunchMode.externalApplication);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Unable to open file")));
            }
          },
          icon: Icon(Icons.open_in_new),
          label: Text("Open Proof Document"),
        ),
      ),
    );
  }
}
