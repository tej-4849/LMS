import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:notesapp/pages/student_assignment_detail_page.dart';

class AssignmentListPage extends StatelessWidget {
  final String teacherId;
  final String teacherName;
  final String studentId;

  AssignmentListPage({required this.teacherId, required this.teacherName, required this.studentId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Assignments by $teacherName", style: TextStyle(color: Colors.white),), backgroundColor: const Color.fromARGB(255, 114, 101, 219),),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(teacherId)
            .collection('assignments')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("No assignments found"));
          }

          return ListView(
            children: snapshot.data!.docs.map((assignmentDoc) {
              var assignmentData = assignmentDoc.data() as Map<String, dynamic>;
              String assignmentName = assignmentData['taskName'] ?? "Untitled Assignment";

              return StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .doc('teacheruser')
                    .collection('teachers')
                    .doc(teacherId) // Change this to current student's ID
                    .collection('assignments')
                    .doc(assignmentDoc.id)
                    .collection('submissions')
                    .doc(studentId)
                    .snapshots(),
                builder: (context, submissionSnapshot) {
                  bool isSubmitted = submissionSnapshot.hasData && submissionSnapshot.data!.exists;

                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      width: double.infinity,
                      height: 100,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 211, 218, 254),
                        borderRadius: BorderRadius.circular(15) 
                      ),
                      child: ListTile(
                        title: Text(assignmentName, style: TextStyle(color: const Color.fromARGB(255, 0, 0, 0), fontWeight: FontWeight.bold),),
                        trailing: Text(isSubmitted ? "✅ Done" : "⏳ Pending", style: TextStyle(color: isSubmitted ? const Color.fromARGB(255, 0, 171, 6) : const Color.fromARGB(255, 231, 19, 3), fontWeight: FontWeight.bold)),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => StudentAssignmentDetailPage(
                                teacherId: teacherId,
                                assignmentId: assignmentDoc.id,
                                assignmentName: assignmentName,
                                isSubmitted: isSubmitted,
                                studentId: studentId,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  );
                },
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
