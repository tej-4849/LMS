import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:file_picker/file_picker.dart';

class LeaveSubmissionPage extends StatefulWidget {
  final bool isStudent; // true for student, false for teacher
  final String userId;
  final String userName;

  LeaveSubmissionPage({
    super.key,
    required this.isStudent,
    required this.userId,
    required this.userName,
  });

  @override
  _LeaveSubmissionPageState createState() => _LeaveSubmissionPageState();
}

class _LeaveSubmissionPageState extends State<LeaveSubmissionPage> {
  final TextEditingController reasonController = TextEditingController();
  DateTime? startDate;
  DateTime? endDate;
  bool isSubmitting = false;

  File? proofFile;
  bool isUploadingFile = false;
  String uploadedFileName = '';
  String? uploadedProofUrl;

  Future<void> _pickProofFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result != null) {
      try {
        setState(() {
          isUploadingFile = true;
        });

        final pickedFile = result.files.first;
        final fileBytes = pickedFile.bytes;
        final fileName = pickedFile.name;

        if (fileBytes == null) {
          throw Exception("File bytes are null");
        }

        String collectionPath =
            widget.isStudent ? 'studentleaves' : 'teacherleaves';

        final ref = FirebaseStorage.instance
            .ref()
            .child('leave_proofs/$collectionPath/$fileName');

        final uploadTask = await ref.putData(fileBytes); // 👈 key change here

        final fileUrl = await ref.getDownloadURL();

        setState(() {
          uploadedProofUrl = fileUrl;
          uploadedFileName = fileName;
          isUploadingFile = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Proof uploaded successfully.")),
        );
      } catch (e) {
        print("Upload error: $e");
        setState(() {
          isUploadingFile = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to upload proof.")),
        );
      }
    }
  }

  Future<void> _submitLeave() async {
    if (reasonController.text.isEmpty ||
        startDate == null ||
        endDate == null ||
        uploadedProofUrl == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                "Please fill all fields and upload proof before submitting.")),
      );
      return;
    }

    setState(() {
      isSubmitting = true;
    });

    String collectionPath =
        widget.isStudent ? 'studentleaves' : 'teacherleaves';

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc('hod')
          .collection('leaves')
          .doc(collectionPath)
          .collection(collectionPath)
          .add({
        'userId': widget.userId,
        'name': widget.userName,
        'reason': reasonController.text,
        'startDate': startDate,
        'endDate': endDate,
        'proofUrl': uploadedProofUrl,
        'status': 'Pending',
        'timestamp': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Leave application submitted successfully.")),
      );

      // Clear all fields
      reasonController.clear();
      setState(() {
        startDate = null;
        endDate = null;
        proofFile = null;
        isSubmitting = false;
        uploadedFileName = '';
        uploadedProofUrl = null;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to submit leave. Try again.")),
      );

      setState(() {
        isSubmitting = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Submit Leave Application",
            style: TextStyle(color: Colors.white)),
        backgroundColor: const Color.fromARGB(255, 41, 129, 82),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Reason for Leave",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              SizedBox(height: 8),
              TextField(
                controller: reasonController,
                maxLines: 3,
                decoration: InputDecoration(
                    hintText: "Enter reason for leave",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(3),
                      borderSide: BorderSide(
                          color: const Color.fromARGB(255, 27, 84, 184),
                          width: 4),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: Colors.blueAccent, width: 4),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: const Color.fromARGB(255, 0, 0, 0),
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(18))),
              ),
              SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Start Date",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20)),
                      SizedBox(height: 8),
                      GestureDetector(
                        onTap: () async {
                          DateTime? picked = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime.now(),
                            lastDate: DateTime.now().add(Duration(days: 365)),
                          );
                          if (picked != null) {
                            setState(() {
                              startDate = picked;
                            });
                          }
                        },
                        child: Container(
                          height: 80,
                          width: 150,
                          decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 34, 169, 85),
                              borderRadius: BorderRadius.circular(15)),
                          child: Center(
                            child: Text(
                              startDate != null
                                  ? "${startDate!.toLocal()}".split(' ')[0]
                                  : "Select Start Date",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      
                      Text("End Date",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20)),
                      SizedBox(height: 8),
                      GestureDetector(
                        onTap: () async {
                          DateTime? picked = await showDatePicker(
                            context: context,
                            initialDate: startDate ?? DateTime.now(),
                            firstDate: DateTime.now(),
                            lastDate: DateTime.now().add(Duration(days: 365)),
                          );
                          if (picked != null) {
                            setState(() {
                              endDate = picked;
                            });
                          }
                        },
                        child: Container(
                          height: 80,
                          width: 150,
                          decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 34, 169, 85),
                              borderRadius: BorderRadius.circular(15)),
                          child: Center(
                            child: Text(
                              endDate != null
                                  ? "${endDate!.toLocal()}".split(' ')[0]
                                  : "Select End Date",
                              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              ///////////

              SizedBox(height: 40),
              

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                
                children: [
                  Text("Upload Proof (PDF/Image)",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              SizedBox(height: 8),
              isUploadingFile
                  ? Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                      children: [

                        CircularProgressIndicator(),
                        SizedBox(width: 12),
                        Text("Uploading...",
                            style: TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    )
                  // : ElevatedButton.icon(
                  //     onPressed: _pickProofFile,
                  //     icon: Icon(Icons.attach_file),
                  //     label: Text(uploadedFileName.isEmpty
                  //         ? "Choose File"
                  //         : "Proof uploaded ✔"),
                  //   ),
                  : GestureDetector(
                    onTap: _pickProofFile,
                    child: Container(
                      height: 75,
                      width: 120,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 24, 117, 27),
                        borderRadius: BorderRadius.circular(15)
                      ),
                      child: Center(
                        child: Text(uploadedFileName.isEmpty
                           ? "Choose File"
                           : "Proof uploaded", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
                      ),
                    
                    ),
                  ),

              SizedBox(height: 80),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ElevatedButton(
                    
                  //   onPressed: isSubmitting ? null : _submitLeave,
                  //   style: ElevatedButton.styleFrom(
                  //     backgroundColor: const Color.fromARGB(255, 8, 186, 76),
                  //     padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                  //     shape: RoundedRectangleBorder(
                  //       borderRadius: BorderRadius.circular(8),
                  //     ),
                  //   ),
                  //   child: isSubmitting
                  //       ? CircularProgressIndicator(color: Colors.white)
                  //       : Text(
                  //           "Submit Leave",
                  //           style: TextStyle(fontSize: 16, color: Colors.white),
                  //         ),
                  // ),

                  GestureDetector(
                    onTap: isSubmitting ? null : _submitLeave,
                    child: Container(
                      height: 75,
                      width: 130,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 4, 75, 31),
                        borderRadius: BorderRadius.circular(15),
                    
                      ),
                      child: isSubmitting
                          ? Center(child: CircularProgressIndicator(color: Colors.white))
                          : Center(
                            child: Text(
                                "Submit Leave",
                                style: TextStyle(fontSize: 16, color: Colors.white),
                              ),
                          ),
                    ),
                  )
                ],
              ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
