import 'dart:io';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart' show Uint8List, kIsWeb;
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;

// ✅ Use universal_html for Web
import 'package:universal_html/html.dart' as html;

class FolderDetailScreen extends StatefulWidget {
  final String teacherId;
  final String folderId;
  final String folderName;
  final bool isTeacher;

  

  FolderDetailScreen({
    required this.teacherId,
    required this.folderId,
    required this.folderName,
    required this.isTeacher,
  });

  @override
  _FolderDetailScreenState createState() => _FolderDetailScreenState();
}

class _FolderDetailScreenState extends State<FolderDetailScreen> {
  
  
  // Function to Upload PDF
  Future<void> _uploadPDF() async {
    if (kIsWeb) {
      final html.FileUploadInputElement input = html.FileUploadInputElement()..accept = 'application/pdf';
      input.click();
      
      input.onChange.listen((event) async {
        final file = input.files!.first;
        final reader = html.FileReader();
        
        reader.readAsArrayBuffer(file);
        reader.onLoadEnd.listen((_) async {
          final fileData = reader.result as Uint8List;
          String fileName = file.name;
          Reference ref = FirebaseStorage.instance
              .ref('studyMaterials/${widget.teacherId}/${widget.folderId}/$fileName');

          UploadTask uploadTask = ref.putData(fileData);
          TaskSnapshot snapshot = await uploadTask;

          String fileUrl = await snapshot.ref.getDownloadURL();

          await FirebaseFirestore.instance
              .collection('users')
              .doc('teacheruser')
              .collection('teachers')
              .doc(widget.teacherId)
              .collection('studyMaterials')
              .doc(widget.folderId)
              .collection('files')
              .add({
            'fileName': fileName,
            'fileUrl': fileUrl,
            'uploadedAt': Timestamp.now(),
          });

          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF Uploaded Successfully!')));
        });
      });

    } else {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );

      if (result != null) {
        PlatformFile file = result.files.first;

        if (file.bytes != null) {
          String fileName = file.name;
          Reference ref = FirebaseStorage.instance
              .ref('studyMaterials/${widget.teacherId}/${widget.folderId}/$fileName');

          UploadTask uploadTask = ref.putData(file.bytes!);
          TaskSnapshot snapshot = await uploadTask;

          String fileUrl = await snapshot.ref.getDownloadURL();

          await FirebaseFirestore.instance
              .collection('users')
              .doc('teacheruser')
              .collection('teachers')
              .doc(widget.teacherId)
              .collection('studyMaterials')
              .doc(widget.folderId)
              .collection('files')
              .add({
            'fileName': fileName,
            'fileUrl': fileUrl,
            'uploadedAt': Timestamp.now(),
          });

          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF Uploaded Successfully!')));
        }
      }
    }
  }

  // Function to Open PDFs
  Future<void> _openPDF(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not open the PDF';
    }
  }

  // Function to Download PDFs
  Future<void> _downloadPDF(String url, String fileName) async {
    if (kIsWeb) {
      // ✅ Web Download
      final html.AnchorElement anchor = html.AnchorElement(href: url)
        ..setAttribute('download', fileName)
        ..click();
    } else {
      // ✅ Android & iOS Download
      var status = await Permission.storage.request();
      if (status.isGranted) {
        final directory = await getExternalStorageDirectory(); // Get downloads directory
        final filePath = '${directory!.path}/$fileName';
        
        final response = await http.get(Uri.parse(url));
        final file = File(filePath);
        
        await file.writeAsBytes(response.bodyBytes);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Downloaded to $filePath')));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Storage permission denied!')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.folderName, style: TextStyle(color: Colors.white),), backgroundColor: const Color.fromARGB(255, 142, 32, 210),),

      backgroundColor: const Color.fromARGB(255, 252, 233, 255),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(widget.teacherId)
            .collection('studyMaterials')
            .doc(widget.folderId)
            .collection('files')
            .orderBy('uploadedAt', descending: true)
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("No PDFs uploaded"));
          }

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              // return ListTile(
              //   title: Text(doc['fileName']),
              //   leading: Icon(Icons.picture_as_pdf, color: Colors.red),
              //   trailing: Row(
              //     mainAxisSize: MainAxisSize.min,
              //     children: [
              //       IconButton(
              //         icon: Icon(Icons.download),
              //         onPressed: () => _downloadPDF(doc['fileUrl'], doc['fileName']), // ✅ Download button
              //       ),
              //       IconButton(
              //         icon: Icon(Icons.open_in_new),
              //         onPressed: () => _openPDF(doc['fileUrl']), // ✅ Open button
              //       ),
              //     ],
              //   ),
              // );

              return GestureDetector(
                onTap: () => _downloadPDF(doc['fileUrl'], doc['fileName']),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 100,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 123, 69, 199),
                      borderRadius: BorderRadius.circular(15),
                  
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          
                          Text(doc['fileName'], style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),),
                
                          Icon(Icons.picture_as_pdf, color: Colors.white,)
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: widget.isTeacher? FloatingActionButton(
        onPressed: _uploadPDF,
        child: Icon(Icons.upload_file),
      ) : null,
    );
  }
}
