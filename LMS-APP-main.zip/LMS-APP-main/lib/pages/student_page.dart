import 'package:flutter/material.dart';
import 'package:notesapp/pages/leave_submission_page.dart';
import 'package:notesapp/pages/past_leaves_page.dart';
import 'package:notesapp/pages/student_study_material_screen.dart';
import 'package:notesapp/pages/view_assignments_page.dart';
import 'package:notesapp/utilities/greeting_cont.dart';
import 'package:notesapp/utilities/module_scroll.dart';
import 'package:notesapp/utilities/progress_cont.dart';
import 'package:notesapp/utilities/progress_view.dart';


class StudentPage extends StatelessWidget {
  final Map<String, dynamic> userData;
  const StudentPage({super.key, required this.userData});
  
  @override
  
  Widget build(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Stack(
            children: [
              Container(
                height: screenHeight / 4,
                width: double.infinity,
                color: const Color.fromARGB(255, 33, 117, 243),
              ),
      
      
              Positioned(
                  top: (screenHeight / 4),
                  child: Container(
                    height: screenHeight * 3 / 3,
                    width: MediaQuery.of(context).size.width,
                    color: Colors.white,
                  )
                  ),
      
      
              Column(
                children: [
                  SizedBox(
                    height: 40,
                  ),
                  Padding(
                      padding: const EdgeInsets.only(left: 30.0, right: 30),
                      child: GreetingCont(userData: userData,)
                      ),
                  
                  SizedBox(height: 40,),
      
                  ProgressCont(studentData: userData,),
      
                  const SizedBox(height: 40,),
      
                  ModuleScroll(userData: userData,),
      
                  const SizedBox(height: 40,),

                  SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: ProgressView(studentData: userData,)),

                  const SizedBox(height: 30,),

                  SingleChildScrollView
                  ( scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>LeaveSubmissionPage(isStudent: true, userId: userData['id'], userName: userData['name'])));
                      },
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                        child: Container(
                          height: 200,
                          width: 200,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 43, 176, 72),
                            borderRadius: BorderRadius.circular(15)
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Apply For leave",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),
                                // Icon(Icons.chat, size: 40,color: Colors.white,)
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    
                    
                    GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>PastLeavesPage(isStudent: true, userId: userData['id'], )));
                      },
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                        child: Container(
                          height: 200,
                          width: 200,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 50, 105, 255),
                            borderRadius: BorderRadius.circular(15)
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("View Past\nLeave\nApplications",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),
                                // Icon(Icons.chat, size: 40,color: Colors.white,)
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    
                    
                    GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>StudentStudyMaterialScreen()));
                      },
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                        child: Container(
                          height: 200,
                          width: 200,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 221, 69, 14),
                            borderRadius: BorderRadius.circular(15)
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("View\nstudy\nmaterials",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),
                                // Icon(Icons.chat, size: 40,color: Colors.white,)
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    
                    GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewAssignmentsPage(userId: userData['id'],)));
                      },
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                        child: Container(
                          height: 200,
                          width: 200,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 120, 35, 5),
                            borderRadius: BorderRadius.circular(15)
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("View\nAssignments",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),
                                // Icon(Icons.chat, size: 40,color: Colors.white,)
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                      ],
                    ),
                  ),

                  
                ],
              ),

              
      


            ],
          ),
    ),
    );
    
     
        
  }
}