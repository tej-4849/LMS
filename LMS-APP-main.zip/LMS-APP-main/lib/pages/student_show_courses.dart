import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class StudentShowCourses extends StatelessWidget {
  final Map<String, dynamic> studentData;

  const StudentShowCourses({super.key, required this.studentData});

  Future<double> _calculateAttendance(
      String teacherId, String courseId, String studentId) async {
    try {
      // Fetch all lectures
      final lecturesSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc('teacheruser')
          .collection('teachers')
          .doc(teacherId)
          .collection('courses')
          .doc(courseId)
          .collection('lectures')
          .get();

      if (lecturesSnapshot.docs.isEmpty) return 0.0;

      int attendedCount = 0;
      int totalLectures = lecturesSnapshot.docs.length;

      // Check attendance for each lecture
      for (var lectureDoc in lecturesSnapshot.docs) {
        final attendanceDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(teacherId)
            .collection('courses')
            .doc(courseId)
            .collection('lectures')
            .doc(lectureDoc.id)
            .collection('attendance')
            .doc(studentId)
            .get();

        if (attendanceDoc.exists) {
          final attendanceData = attendanceDoc.data();
          if (attendanceData != null && attendanceData['status'] == 'Present') {
            attendedCount++;
          }
        }
      }

      return (attendedCount / totalLectures) * 100;
    } catch (e) {
      return 0.0; // Return 0 in case of an error
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Courses"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .snapshots(),
        builder: (context, teacherSnapshot) {
          if (teacherSnapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (teacherSnapshot.hasError || !teacherSnapshot.hasData) {
            return const Center(child: Text("Failed to fetch courses"));
          }

          final teacherDocs = teacherSnapshot.data!.docs;

          return ListView.builder(
            itemCount: teacherDocs.length,
            itemBuilder: (context, index) {
              final teacherDoc = teacherDocs[index];
              final coursesCollection = teacherDoc.reference
                  .collection('courses')
                  .where('division', isEqualTo: studentData['division']);

              return FutureBuilder<QuerySnapshot>(
                future: coursesCollection.get(),
                builder: (context, courseSnapshot) {
                  if (courseSnapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (!courseSnapshot.hasData || courseSnapshot.data!.docs.isEmpty) {
                    return Container();
                  }

                  final courses = courseSnapshot.data!;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: courses.docs.map((courseDoc) {
                      final courseData = courseDoc.data() as Map<String, dynamic>;

                      return FutureBuilder<double>(
                        future: _calculateAttendance(
                            teacherDoc.id, courseDoc.id, studentData['id']),
                        builder: (context, attendanceSnapshot) {
                          final attendancePercentage =
                              attendanceSnapshot.data?.toStringAsFixed(1) ?? '--';

                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(15)),
                            margin: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 16),
                            child: ListTile(
                              title: Text(
                                courseData['courseName'] ?? 'Unnamed Course',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                "Created by: ${teacherDoc['name'] ?? 'Unknown'}",
                                style: const TextStyle(color: Colors.white),
                              ),
                              trailing: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "Division: ${courseData['division']}",
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    "Attendance: $attendancePercentage%",
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    }).toList(),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
