import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class ComplaintDetailPage extends StatelessWidget {
  final Map<String, dynamic> data;
  const ComplaintDetailPage({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final message = data['message'] ?? "No message provided.";
    final imageUrl = data['imageUrl'];
    final name = data['studentName'] ?? "Unknown";
    final year = data['year'] ?? "Unknown";
    final division = data['division'] ?? "Unknown";
    final submittedAt = data['submittedAt'];
    final formattedDate = submittedAt != null
        ? (submittedAt.toDate()).toString()
        : 'Unknown';

    return Scaffold(
      appBar: AppBar(
        title: Text("Complaint Details", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Student Info
                Row(
                  children: [
                    Icon(Icons.person, color: Colors.indigo),
                    SizedBox(width: 8),
                    Text(name,
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ],
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.school, size: 20, color: Colors.grey[700]),
                    SizedBox(width: 6),
                    Text("Year: $year | Division: $division",
                        style: TextStyle(fontSize: 16, color: Colors.grey[800])),
                  ],
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.access_time, size: 20, color: Colors.grey[700]),
                    SizedBox(width: 6),
                    Text("Submitted at: $formattedDate",
                        style: TextStyle(fontSize: 15, color: Colors.grey[700])),
                  ],
                ),
                Divider(height: 30, thickness: 1.2),

                // Complaint Message
                Text("Complaint",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                SizedBox(height: 10),
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Text(
                    message,
                    style: TextStyle(fontSize: 16, height: 1.4),
                  ),
                ),

                // Attached Image
                if (imageUrl != null && imageUrl != '') ...[
                  SizedBox(height: 30),
                  Text("Attached Image",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.network(
                      imageUrl,
                      height: 250,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
