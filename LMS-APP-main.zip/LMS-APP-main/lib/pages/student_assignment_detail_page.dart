import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:url_launcher/url_launcher.dart';

class StudentAssignmentDetailPage extends StatefulWidget {
  final String teacherId;
  final String assignmentId;
  final String assignmentName;
  final bool isSubmitted;
  final String studentId;

  StudentAssignmentDetailPage({
    required this.teacherId,
    required this.assignmentId,
    required this.assignmentName,
    required this.isSubmitted,
    required this.studentId,
  });

  @override
  _StudentAssignmentDetailPageState createState() => _StudentAssignmentDetailPageState();
}

class _StudentAssignmentDetailPageState extends State<StudentAssignmentDetailPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  bool isUploading = false;

  Future<void> _submitAssignmentPDF() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      withData: true,
    );

    if (result != null) {
      setState(() => isUploading = true);

      String fileName = result.files.single.name;
      String storagePath = "submissions/${widget.teacherId}/${widget.assignmentId}/your_student_id.pdf"; 

      try {

        DocumentSnapshot studentDoc = await _firestore.collection('users').doc('studentuser').collection('students').doc(widget.studentId).get();

        String studentName = studentDoc.exists ? studentDoc.get('name') : "Unknown Student";


        Uint8List fileBytes = result.files.single.bytes!;
        UploadTask uploadTask = _storage.ref(storagePath).putData(fileBytes);

        TaskSnapshot snapshot = await uploadTask;
        String downloadUrl = await snapshot.ref.getDownloadURL();

        await _firestore
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .doc(widget.teacherId)
            .collection('assignments')
            .doc(widget.assignmentId)
            .collection('submissions')
            .doc(widget.studentId) 
            .set({
          'fileUrl': downloadUrl,
          'submittedAt': Timestamp.now(),
          'studentName': studentName, 
        });

        setState(() => isUploading = false);

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Assignment Submitted!")));
        Navigator.pop(context);
      } catch (e) {
        setState(() => isUploading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Upload failed!")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.assignmentName, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      
      ), backgroundColor: const Color.fromARGB(255, 179, 51, 0),
      iconTheme: IconThemeData(
        color: Colors.white
      ),
      ),
      backgroundColor: widget.isSubmitted?   const Color.fromARGB(255, 235, 255, 236) : const Color.fromARGB(255, 255, 228, 224) ,
      
      body: StreamBuilder<DocumentSnapshot>(
  stream: _firestore
      .collection('users')
      .doc('teacheruser')
      .collection('teachers')
      .doc(widget.teacherId)
      .collection('assignments')
      .doc(widget.assignmentId)
      .snapshots(),
  builder: (context, snapshot) {
    if (!snapshot.hasData || !snapshot.data!.exists) {
      return Center(child: Text("Assignment not found"));
    }

    var assignmentData = snapshot.data!.data() as Map<String, dynamic>? ?? {};
    String assignmentFileUrl = assignmentData['assignmentFile'] ?? "";

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 📄 Assignment File (Uploaded by Teacher)
        if (assignmentFileUrl.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: double.infinity,
              height: 100,
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 197, 69, 30),
                borderRadius: BorderRadius.circular(15)
              ),
              child: ListTile(
                title: const Text("📄 Tap to View Assignment", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
                onTap: () async {
                  if (await canLaunchUrl(Uri.parse(assignmentFileUrl))) {
                    await launchUrl(Uri.parse(assignmentFileUrl), mode: LaunchMode.externalApplication);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Could not open file")),
                    );
                  }
                },
              ),
            ),
          ),

        // 📌 Fetch & Display Student Submission
        StreamBuilder<DocumentSnapshot>(
          stream: _firestore
              .collection('users')
              .doc('teacheruser')
              .collection('teachers')
              .doc(widget.teacherId)
              .collection('assignments')
              .doc(widget.assignmentId)
              .collection('submissions')
              .doc(widget.studentId) // Student's submission
              .snapshots(),
          builder: (context, submissionSnapshot) {
            if (!submissionSnapshot.hasData || !submissionSnapshot.data!.exists) {
              return const Center(
                child: Text(
                  "No submission uploaded yet.",
                  style: TextStyle(color: Color.fromARGB(255, 101, 101, 101)),
                ),
              );
            }

            var submissionData = submissionSnapshot.data!.data() as Map<String, dynamic>;
            String fileUrl = submissionData['fileUrl'] ?? "";
            int marks = submissionData['marks'] ?? -1; // Default: Not Graded

            return Card(
              elevation: 4,
              margin: EdgeInsets.all(12),
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Your Submission",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),

                    // 🔗 Submitted PDF File
                    Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "View Submitted File",
                            style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                          ),
                          IconButton(
                            icon: Icon(Icons.open_in_new, color: Colors.blue),
                            onPressed: () async {
                              if (await canLaunchUrl(Uri.parse(fileUrl))) {
                                await launchUrl(Uri.parse(fileUrl), mode: LaunchMode.externalApplication);
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text("Could not open file")),
                                );
                              }
                            },
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 12),

                    // ✅ Marks Display
                    Text(
                      "Marks: ${marks == -1 ? "Not Graded Yet" : "$marks/10"}",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: marks == -1 ? Colors.grey : Colors.green,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),


        const SizedBox(height: 40,),

        // 📩 Submit Assignment Button (if not uploaded)
        if (!widget.isSubmitted)
          // ElevatedButton(
          //   onPressed: isUploading ? null : _submitAssignmentPDF,
          //   child: isUploading ? CircularProgressIndicator() : Text("Submit Assignment"),
          // ),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                  onTap: (){
                    isUploading? null : _submitAssignmentPDF();
                  },
                  child: Container(
                    height: 50,
                    width: 150,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 67, 153, 70),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: isUploading? Center(child: CircularProgressIndicator(color: Colors.white,)) : Center(child: Text("Submit Assignment", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),)),
                  ),
                ),
              ),
            ],
          )
      ],
    );
  },
),

    );
  }
}
