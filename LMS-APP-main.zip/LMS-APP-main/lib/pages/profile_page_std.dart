import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  final Map<String, dynamic> userData;

  const ProfilePage({super.key, required this.userData});

  @override
  Widget build(BuildContext context) {
    print('Image URL: ${userData['imageUrl']}');
    return Scaffold(
      appBar: AppBar(
        title: Text('My Profile', style: TextStyle(color: Colors.white),),
        backgroundColor: const Color.fromARGB(255, 76, 129, 195),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            
            // Profile picture
            Center(
              child: CircleAvatar(
                radius: 60,
                backgroundImage: userData['imageUrl'] != null
                    ? NetworkImage(userData['imageUrl'])
                    : AssetImage('assets/default_avatar.png') as ImageProvider,
                    
              ),
            ),
            SizedBox(height: 20),

            // Name
            Text(
              userData['name'] ?? 'Name not available',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),

            SizedBox(height: 10),

            // PRN
            Text(
              'PRN: ${userData['prn'] ?? 'N/A'}',
              style: TextStyle(fontSize: 18),
            ),

            SizedBox(height: 5),

            // Year
            Text(
              'Year: ${userData['year'] ?? 'N/A'}',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
