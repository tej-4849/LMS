import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CreateTimeTableScreen extends StatefulWidget {
  const CreateTimeTableScreen({super.key});

  @override
  State<CreateTimeTableScreen> createState() => _CreateTimeTableScreenState();
}

class _CreateTimeTableScreenState extends State<CreateTimeTableScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final List<String> years = ['2nd Year', '3rd Year', '4th Year'];
  final List<String> divisions = ['C', 'D', 'E'];
  final List<String> classes = ['CSCR01', 'CSCR02', 'CSCR03', 'CSCR04', 'CSCR05'];

  String? selectedYear;
  String? selectedDivision;
  String? selectedClass;

  final List<String> timeSlots = [
    '09:00 AM - 10:00 AM',
    '10:00 AM - 11:00 AM',
    '11:30 AM - 12:30 PM',
    '12:30 PM - 01:30 PM',
    '14:30 PM - 15:30 PM',
    '15:30 PM - 16:30 PM',
  ];

  final List<String> days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  Map<String, Map<String, Map<String, TextEditingController>>> timetableControllers = {};
  List<Map<String, dynamic>> teachers = [];

  @override
  void initState() {
    super.initState();
    _fetchTeachers();
    _initializeTimetable();
  }

  Future<void> _fetchTeachers() async {
    try {
      var teachersDocs = await _firestore.collection('users').doc('teacheruser').collection('teachers').get();
      setState(() {
        teachers = teachersDocs.docs.map((doc) {
          var data = doc.data();
          return {
            'name': data['name'] ?? 'Unknown',
            'subject': data['subject'] ?? 'Unknown',
          };
        }).toList();
      });
    } catch (e) {
      print("Error fetching teachers: $e");
    }
  }

  void _initializeTimetable() {
    for (String day in days) {
      timetableControllers[day] = {};
      for (String time in timeSlots) {
        timetableControllers[day]![time] = {
          'subject': TextEditingController(),
          'faculty': TextEditingController(),
        };
      }
    }
  }

  Future<void> saveTimeTable() async {
    if (selectedYear == null || selectedDivision == null || selectedClass == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select Year, Division, and Class")),
      );
      return;
    }

    Map<String, Map<String, Map<String, String>>> timetableData = {};
    for (String day in days) {
      timetableData[day] = {};
      for (String time in timeSlots) {
        timetableData[day]![time] = {
          'subject': timetableControllers[day]![time]!['subject']!.text.isEmpty
              ? "abc"
              : timetableControllers[day]![time]!['subject']!.text,
          'faculty': timetableControllers[day]![time]!['faculty']!.text.isEmpty
              ? "xyz"
              : timetableControllers[day]![time]!['faculty']!.text,
        };
      }
    }

    try {
      await _firestore
          .collection('users')
          .doc('hod')
          .collection('timetables')
          .doc(selectedYear)
          .collection('divisions')
          .doc(selectedDivision)
          .collection('classes')
          .doc(selectedClass)
          .set({
        'year': selectedYear,
        'division': selectedDivision,
        'class': selectedClass,
        'timetable': timetableData,
        'timestamp': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Timetable Created Successfully")),
      );

      Navigator.pop(context);
    } catch (e) {
      print("Error saving timetable: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Timetable")),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Dropdowns for Year, Division, and Class
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: selectedYear,
                            hint: Text("Select Year"),
                            items: years.map((year) {
                              return DropdownMenuItem(value: year, child: Text(year));
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                selectedYear = value;
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: selectedDivision,
                            hint: const Text("Select Division"),
                            items: divisions.map((div) {
                              return DropdownMenuItem(value: div, child: Text(div));
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                selectedDivision = value;
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: selectedClass,
                            hint: Text("Select Class"),
                            items: classes.map((cls) {
                              return DropdownMenuItem(value: cls, child: Text(cls));
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                selectedClass = value;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),

                    // Timetable table with teacher list
                    Container(
                      height: MediaQuery.of(context).size.height * 1,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Timetable Table (Scrollable)
                          Expanded(
                            flex: 3,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: SingleChildScrollView(
                                scrollDirection: Axis.vertical,
                                child: DataTable(
                                  dataRowMinHeight: 100,
                                  dataRowMaxHeight: 100,
                                  columnSpacing: 10,
                                  border: TableBorder.all(),
                                  columns: [
                                    DataColumn(label: Text("Time Slot")),
                                    ...days.map((day) => DataColumn(label: Text(day))).toList()
                                  ],
                                  rows: timeSlots.map((time) {
                                    return DataRow(cells: [
                                      DataCell(Text(time)),
                                      ...days.map((day) {
                                        return DataCell(
                                          Column(
                                            children: [
                                              TextField(
                                                controller: timetableControllers[day]![time]!['subject'],
                                                decoration: InputDecoration(hintText: "Enter Subject"),
                                              ),
                                              TextField(
                                                controller: timetableControllers[day]![time]!['faculty'],
                                                decoration: InputDecoration(hintText: "Enter Faculty"),
                                              ),
                                            ],
                                          ),
                                        );
                                      }).toList(),
                                    ]);
                                  }).toList(),
                                ),
                              ),
                            ),
                          ),

                          // Teacher List
                          Expanded(
                            flex: 1,
                            child: Container(
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(border: Border(left: BorderSide(color: Colors.black))),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Teachers List", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                  Divider(),
                                  Expanded(
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      physics: ClampingScrollPhysics(),
                                      itemCount: teachers.length,
                                      itemBuilder: (context, index) {
                                        return ListTile(
                                          title: Text(teachers[index]['name']!),
                                          subtitle: Text("Subject: ${teachers[index]['subject']}"),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 20),
                    Center(
                      child: ElevatedButton(
                        onPressed: saveTimeTable,
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                          backgroundColor: Colors.blue,
                        ),
                        child: Text("Save Timetable", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
