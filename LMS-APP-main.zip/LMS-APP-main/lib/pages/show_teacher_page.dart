import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:notesapp/elements/my_user_listview.dart';
import 'package:notesapp/services/firestore.dart';

class ShowTeacherPage extends StatefulWidget {
  const ShowTeacherPage({super.key});

  @override
  State<ShowTeacherPage> createState() => _ShowTeacherPageState();
}

class _ShowTeacherPageState extends State<ShowTeacherPage> {
  final FirestoreService firestoreService = FirestoreService();

  final TextStyle infoTextStyle =
      TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white);
  final TextStyle subinfoTextStyle =
      TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Teachers' List"),
          centerTitle: true,
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: firestoreService.getTeacherStream(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return const Center(child: Text("An error occurred!"));
            }

            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return const Center(child: Text("No teachers' data found."));
            }

            List teacherList = snapshot.data!.docs;
            print(
                "Teacher List: $teacherList"); // Check if this is printing the data as expected

            return ListView.builder(
              itemCount: teacherList.length,
              itemBuilder: (context, index) {
                DocumentSnapshot document = teacherList[index];
                Map<String, dynamic> mappedTeacherData =
                    document.data() as Map<String, dynamic>;

                // Debug print to verify each teacher's data
                print("Mapped Teacher Data: $mappedTeacherData");

                return MyUserListview(
                  name: mappedTeacherData['name'],
                  email: mappedTeacherData['email'],
                  password: mappedTeacherData['password'],
                  subject: mappedTeacherData['subject'],
                  imageUrl: mappedTeacherData['imageUrl'], // 🆕
                );
              },
            );
          },
        ));
  }
}
