import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:notesapp/elements/my_textfield.dart';
import 'package:notesapp/services/firestore.dart';

class AddUsersPage extends StatefulWidget {
  const AddUsersPage({super.key});

  @override
  State<AddUsersPage> createState() => _AddUsersPageState();
}

class _AddUsersPageState extends State<AddUsersPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();

  final TextEditingController stdnameController = TextEditingController();
  final TextEditingController stdemailController = TextEditingController();
  final TextEditingController stdpasswordController = TextEditingController();
  final TextEditingController prnController = TextEditingController();
  final TextEditingController divisionController = TextEditingController();
  final TextEditingController yearController = TextEditingController();

  Uint8List? teacherImage;
  String? teacherImageUrl;

  Uint8List? studentImage;
  String? studentImageUrl;

  final FirestoreService firestoreService = FirestoreService();

  bool isTeacherUploading = false;
  bool isStudentUploading = false;

  Future<void> uploadImage(bool isTeacher) async {
  final result = await FilePicker.platform.pickFiles(type: FileType.image);
  if (result != null && result.files.single.bytes != null) {
    final fileBytes = result.files.single.bytes!;
    final fileName = DateTime.now().millisecondsSinceEpoch.toString();

    final ref = FirebaseStorage.instance.ref('profile_photos/$fileName');

    // 👇 Upload with metadata
    final metadata = SettableMetadata(contentType: 'image/jpeg');
    final uploadTask = ref.putData(fileBytes, metadata);

    // Optional: show progress
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Center(child: CircularProgressIndicator()),
    );

    await uploadTask;
    final url = await ref.getDownloadURL();

    if (mounted) Navigator.pop(context); // Remove the progress dialog

    setState(() {
      if (isTeacher) {
        teacherImage = fileBytes;
        teacherImageUrl = url;
      } else {
        studentImage = fileBytes;
        studentImageUrl = url;
      }
    });
  }
}



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Users"), centerTitle: true),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        child: Column(
          children: [
            _buildUserSection(
              title: "Add Teacher",
              controllers: [nameController, emailController, passwordController, subjectController],
              image: teacherImage,
              imageUrl: teacherImageUrl,
              onUploadImage: () => uploadImage(true),
              onSubmit: () {
                firestoreService.addTeacherUser(
                  nameController.text,
                  emailController.text,
                  passwordController.text,
                  subjectController.text,
                  teacherImageUrl ?? '',
                );

                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Teacher added successfully!")));
                nameController.clear();
                emailController.clear();
                passwordController.clear();
                subjectController.clear();
                setState(() {
                  teacherImage = null;
                  teacherImageUrl = null;
                });
              },
            ),
            const SizedBox(height: 50),
            _buildUserSection(
              title: "Add Student",
              controllers: [stdnameController, stdemailController, stdpasswordController, prnController, divisionController, yearController],
              image: studentImage,
              imageUrl: studentImageUrl,
              onUploadImage: () => uploadImage(false),
              onSubmit: () {
                firestoreService.addStudent(
                  stdnameController.text,
                  stdemailController.text,
                  stdpasswordController.text,
                  prnController.text,
                  divisionController.text,
                  yearController.text,
                  studentImageUrl ?? '',
                );

                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Student added successfully!")));
                stdnameController.clear();
                stdemailController.clear();
                stdpasswordController.clear();
                prnController.clear();
                divisionController.clear();
                yearController.clear();
                setState(() {
                  studentImage = null;
                  studentImageUrl = null;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserSection({
    required String title,
    required List<TextEditingController> controllers,
    required Uint8List? image,
    required String? imageUrl,
    required VoidCallback onUploadImage,
    required VoidCallback onSubmit,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.only(bottom: 20, top: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: const Color.fromARGB(255, 203, 203, 203),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          for (final controller in controllers)
            MyTextfield(
              textEditingController: controller,
              hintText: "Enter ${controller == subjectController ? "Subject" : controller == prnController ? "PRN" : controller == divisionController ? "Division" : controller == yearController ? "Year" : controller == emailController || controller == stdemailController ? "Email" : controller == passwordController || controller == stdpasswordController ? "Password" : "Name"}",
            ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100,
                height: 100,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  image: image != null
                      ? DecorationImage(image: MemoryImage(image), fit: BoxFit.cover)
                      : null,
                ),
                child: image == null
                    ? const Center(child: Text("No Image", style: TextStyle(fontSize: 12)))
                    : null,
              ),
              Row(
  mainAxisSize: MainAxisSize.min,
  children: [
    ElevatedButton(
      onPressed: onUploadImage,
      child: Text("Upload Photo"),
    ),
    const SizedBox(width: 10),
    if ((title == "Add Teacher" && isTeacherUploading) ||
        (title == "Add Student" && isStudentUploading))
      SizedBox(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(strokeWidth: 2),
      ),
  ],
),

            ],
          ),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: onSubmit,
            child: Container(
              height: 60,
              width: 100,
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(15),
              ),
              child: const Center(
                child: Text("SUBMIT", style: TextStyle(fontSize: 20, color: Colors.white)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
