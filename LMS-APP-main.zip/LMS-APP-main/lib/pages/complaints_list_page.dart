import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'complaint_detail_page.dart';

class ComplaintsListPage extends StatelessWidget {
  const ComplaintsListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Student Complaints", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),), backgroundColor: const Color.fromARGB(255, 165, 20, 9),),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('complaints')
            .orderBy('submittedAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData)
            return Center(child: CircularProgressIndicator());

          final complaints = snapshot.data!.docs;

          if (complaints.isEmpty)
            return Center(child: Text("No complaints found."));

          return ListView.builder(
            itemCount: complaints.length,
            itemBuilder: (context, index) {
              final data = complaints[index].data() as Map<String, dynamic>;

              final timestamp = data['submittedAt'] as Timestamp?;
              final dateTime = timestamp?.toDate();
              final formattedDate = dateTime != null
                  ? "${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}"
                  : "Unknown time";

              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 192, 64, 49),
                    borderRadius: BorderRadius.circular(15)
                  ),
                  child: ListTile(
                    title: Text(data['studentName'] ?? 'Unknown', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
                    subtitle: Text(
                      "${data['year'] ?? 'Year'} - ${data['division'] ?? 'Div'}\nSubmitted: $formattedDate",
                      style: TextStyle(height: 1.4, color: const Color.fromARGB(255, 236, 236, 236)),
                    ),
                    isThreeLine: true,
                    trailing: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.arrow_forward_ios, color: Colors.white,),
                      ],
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ComplaintDetailPage(data: data),
                        ),
                      );
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
