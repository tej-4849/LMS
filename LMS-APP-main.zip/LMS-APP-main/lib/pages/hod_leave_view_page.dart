import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'ProofViewerPage.dart';

class HodLeaveViewPage extends StatelessWidget {
  const HodLeaveViewPage({super.key});

  Future<void> _updateStatus(
      String collection, String docId, String status) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc('hod')
        .collection('leaves')
        .doc(collection)
        .collection(collection)
        .doc(docId)
        .update({'status': status});
  }

  Widget _buildLeaveList(String collection) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc('hod')
          .collection('leaves')
          .doc(collection)
          .collection(collection)
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(child: Text("No leave applications found."));
        }

        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            var leave = snapshot.data!.docs[index];
            var docId = leave.id;

            return Card(
              color: const Color.fromARGB(255, 47, 70, 64),
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: ListTile(
                title: Text("${leave['name']} (${leave['userId']})", style: TextStyle(color: Colors.white),),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Reason: ${leave['reason']}", style: TextStyle(color: const Color.fromARGB(255, 184, 184, 184))),
                    Text(
                        "Dates: ${leave['startDate'].toDate().toString().substring(0, 10)} to ${leave['endDate'].toDate().toString().substring(0, 10)}", style: TextStyle(color: const Color.fromARGB(255, 184, 184, 184))),
                    Text("Status: ${leave['status']}", style: TextStyle(color: leave['status'] == 'Pending'? Colors.amber : leave['status'] == 'Approved' ? Colors.green : Colors.red)),
                  ],
                ),
                trailing: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (leave['status'] == 'Pending')
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            onPressed: () =>
                                _updateStatus(collection, docId, 'Approved'),
                            icon: Icon(Icons.check, color: Colors.green),
                          ),
                          IconButton(
                            onPressed: () =>
                                _updateStatus(collection, docId, 'Rejected'),
                            icon: Icon(Icons.cancel, color: Colors.red),
                          ),
                        ],
                      ),
                    IconButton(
                      onPressed: () {
                        if (leave['proofUrl'] != null) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  ProofViewerPage(proofUrl: leave['proofUrl']),
                            ),
                          );
                        }
                      },
                      icon: Icon(Icons.picture_as_pdf, color: const Color.fromARGB(255, 238, 238, 238)),
                      tooltip: "View Proof",
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text("Leave Applications"),
          bottom: TabBar(
            tabs: [
              Tab(text: "Student Leaves"),
              Tab(text: "Teacher Leaves"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildLeaveList('studentleaves'),
            _buildLeaveList('teacherleaves'),
          ],
        ),
      ),
    );
  }
}
