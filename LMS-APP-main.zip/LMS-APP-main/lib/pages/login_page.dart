import 'package:flutter/material.dart';
import 'package:notesapp/elements/my_textfield.dart';
import 'package:notesapp/pages/student_page.dart';
import 'package:notesapp/pages/teacher_page.dart';
import 'package:notesapp/pages/hod_page.dart'; // Import HOD page
import 'package:notesapp/services/firestore.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final FirestoreService firestoreService = FirestoreService();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController roleController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
       
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 187, 198, 255),
        
      ),
      backgroundColor: const Color.fromARGB(255, 187, 198, 255),
      body: Center(
        child: Container(
          height: 620,
          width: 400,
          decoration: BoxDecoration(
            color: const Color.fromARGB(255, 242, 245, 255),
            borderRadius: BorderRadius.circular(15)
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 5),
                child: Icon(Icons.lock, size: 150,color: const Color.fromARGB(255, 43, 146, 150),),
                
              ),

              Text("Log in into your Account", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),),
              
              ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: 600,
                ),
                child: Column(
                  children: [
                    MyTextfield(
                    textEditingController: emailController, hintText: "Email"),
                MyTextfield(
                    textEditingController: passwordController, hintText: "Password"),
                MyTextfield(
                    textEditingController: roleController,
                    hintText: "Role: teacheruser/studentuser/hod"),
                  ],
                ),
              ),
          
              const SizedBox(
                height: 40,
              ),
              GestureDetector(
                onTap: () async {
                  try {
                    // Login through Firestore service
                    final userData = await firestoreService.login(
                      emailController.text.trim(),
                      passwordController.text.trim(),
                      roleController.text.trim(),
                    );
          
                    Map<String, dynamic> mappedUserData = userData as Map<String, dynamic>;
          
                    // Role-based navigation
                    if (roleController.text.trim() == 'teacheruser') {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TeacherPage(userData: mappedUserData),
                        ),
                      );
                    } else if (roleController.text.trim() == 'studentuser') {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => StudentPage(userData: mappedUserData),
                        ),
                      );
                    } else if (roleController.text.trim() == 'hod') {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HodPage(userData: mappedUserData), // HOD Dashboard
                        ),
                      );
                    } else {
                      // Invalid role
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Invalid role entered!")),
                      );
                    }
                  } catch (e) {
                    // Handle login errors
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(e.toString())),
                    );
                  }
                },
                child: Container(
                  height: 60,
                  width: 100,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 13, 37, 103),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Text(
                      "SUBMIT",
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
