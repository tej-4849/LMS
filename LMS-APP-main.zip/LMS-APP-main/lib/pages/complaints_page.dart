import 'dart:typed_data';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';

class ComplaintPage extends StatefulWidget {
  final Map<String, dynamic> userData;
  const ComplaintPage({super.key, required this.userData});

  @override
  State<ComplaintPage> createState() => _ComplaintPageState();
}

class _ComplaintPageState extends State<ComplaintPage> {
  final TextEditingController _messageController = TextEditingController();
  Uint8List? _webImageBytes;
  File? _imageFile;
  String? _fileName;
  bool _isSubmitting = false;

  Future<void> _pickImage() async {
    if (kIsWeb) {
      FilePickerResult? result =
          await FilePicker.platform.pickFiles(type: FileType.image);
      if (result != null && result.files.first.bytes != null) {
        setState(() {
          _webImageBytes = result.files.first.bytes;
          _fileName = result.files.first.name;
        });
      }
    } else {
      final pickedFile =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        setState(() {
          _imageFile = File(pickedFile.path);
          _fileName = pickedFile.name;
        });
      }
    }
  }

  Future<void> _submitComplaint() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please enter your complaint message.")),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    String? imageUrl;
    if (_webImageBytes != null || _imageFile != null) {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('complaint_images')
          .child('${DateTime.now().millisecondsSinceEpoch}_$_fileName');

      UploadTask uploadTask;

      if (kIsWeb && _webImageBytes != null) {
        uploadTask = storageRef.putData(_webImageBytes!);
      } else if (_imageFile != null) {
        uploadTask = storageRef.putFile(_imageFile!);
      } else {
        uploadTask = throw Exception("No image to upload");
      }

      final snapshot = await uploadTask.whenComplete(() {});
      imageUrl = await snapshot.ref.getDownloadURL();
    }

    await FirebaseFirestore.instance.collection('complaints').add({
      'studentId': widget.userData['id'],
      'studentName': widget.userData['name'],
      'year':widget.userData['year'],
      'division':widget.userData['division'],
      'message': message,
      'imageUrl': imageUrl,
      'submittedAt': Timestamp.now(),
    });

    setState(() {
      _isSubmitting = false;
      _messageController.clear();
      _webImageBytes = null;
      _imageFile = null;
      _fileName = null;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Complaint submitted successfully.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Send Complaint"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: _messageController,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: "Describe your issue here...",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            if (_webImageBytes != null || _imageFile != null)
              Container(
                height: 150,
                child: kIsWeb
                    ? Image.memory(_webImageBytes!)
                    : Image.file(_imageFile!),
              ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: _pickImage,
              icon: Icon(Icons.photo),
              label: Text("Upload Image (Optional)"),
            ),
            const SizedBox(height: 30),
            _isSubmitting
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _submitComplaint,
                    child: Text("Submit Complaint"),
                  ),
          ],
        ),
      ),
    );
  }
}
