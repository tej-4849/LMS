import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'folder_details_screen.dart';

class StudentStudyMaterialScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Study Materials", style: TextStyle(color: Colors.white),), backgroundColor: const Color.fromARGB(255, 25, 64, 97),),
      backgroundColor: const Color.fromARGB(255, 199, 230, 255),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc('teacheruser')
            .collection('teachers')
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> teacherSnapshot) {
          if (teacherSnapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!teacherSnapshot.hasData || teacherSnapshot.data!.docs.isEmpty) {
            return Center(child: Text("No study materials available"));
          }

          return ListView(
            children: teacherSnapshot.data!.docs.map((teacherDoc) {
              String teacherId = teacherDoc.id;
              String teacherName = teacherDoc['name'];

              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
                child: Card(
                  elevation: 3,
                  color: const Color.fromARGB(255, 28, 80, 123),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)
                  ),
                  child: ExpansionTile(
                    title: Text(teacherName, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    children: [
                      StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection('users')
                            .doc('teacheruser')
                            .collection('teachers')
                            .doc(teacherId)
                            .collection('studyMaterials')
                            .orderBy('createdAt', descending: true)
                            .snapshots(),
                        builder: (context, AsyncSnapshot<QuerySnapshot> folderSnapshot) {
                          if (folderSnapshot.connectionState == ConnectionState.waiting) {
                            return Center(child: CircularProgressIndicator());
                          }
                  
                          if (!folderSnapshot.hasData || folderSnapshot.data!.docs.isEmpty) {
                            return ListTile(title: Text("No folders created", style: TextStyle(color: const Color.fromARGB(255, 213, 213, 213)),));
                          }
                  
                          return Column(
                            children: folderSnapshot.data!.docs.map((folder) {
                              return ListTile(
                                iconColor: Colors.white,
                                title: Text(folder['folderName'], style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
                                trailing: Icon(Icons.folder, color: Colors.white,),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => FolderDetailScreen(
                                        teacherId: teacherId,
                                        folderId: folder.id,
                                        folderName: folder['folderName'],
                                        isTeacher: false,
                                      ),
                                    ),
                                  );
                                },
                              );
                            }).toList(),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
