// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:notesapp/sarv_notes.dart';
// import 'package:notesapp/services/firestore.dart';

// class HomePage extends StatefulWidget {
//   const HomePage({super.key});

//   @override
//   State<HomePage> createState() => _HomePageState();
// }

// class _HomePageState extends State<HomePage> {

//   final FirestoreService firestoreService = FirestoreService();

//   final TextEditingController textController = TextEditingController();

//   final TextEditingController sarvTextController = TextEditingController();

//   void openNoteBox({String? docId}){
//     showDialog(
      
//       context: context, 
//       builder: (context)=>AlertDialog(
//         content: TextField(
//           controller: textController,
//         ),
//         actions: [
//           ElevatedButton(onPressed: () {
//             if(docId == null) firestoreService.addNote(textController.text);
//             // update
//             else firestoreService.updateNote(docId, textController.text);
//             textController.clear();
//             Navigator.pop(context);
//           }, 
//           child: Text('Add'),)
//         ],
//       )
//       );

    
//   }
//   void openSarvNotes({String? docId}){
//       showDialog(
//         context: context, 
//         builder: (context)=>AlertDialog(
//           content: TextField(
//             controller: sarvTextController,
//           ),
//           actions: [
//             ElevatedButton(
//               onPressed: (){
//                 if(docId == null) firestoreService.addSarvNote(sarvTextController.text);
//                 Navigator.pop(context);
//                 Navigator.push(context, (MaterialPageRoute(builder: (context) => SarvNotes(),)));

//               }, 
//               child: Text('add sarvesh notes'))
//           ],

//         ));
//     }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Notes"),
//         backgroundColor: Colors.blue,
//       ),

//       floatingActionButton: Column(
//         mainAxisAlignment: MainAxisAlignment.end,
//         children: [

//           FloatingActionButton(
//             heroTag: "sarvnotes",
//             onPressed: (){
//               openSarvNotes();


//             },
//             child: Icon(Icons.add, color: Colors.green,),),

//           FloatingActionButton(
//             heroTag: "regularnotes",
//             onPressed: (){
//               openNoteBox();
//             },
//             child: Icon(Icons.add),
//             ),
//         ],
//       ),

//       body: StreamBuilder<QuerySnapshot>(
//         stream: firestoreService.getNoteStream(), 
//         builder: (context, snapshot){
//           if(snapshot.hasData){
//             List notesList = snapshot.data!.docs;

//             //display a list
//             return ListView.builder(
//               itemCount: notesList.length,
//               itemBuilder: (context, index){
//               //get individual document
//               DocumentSnapshot document = notesList[index];
//               String docId = document.id;

//               //get note from each doc
//               Map<String, dynamic> data = document.data() as Map<String, dynamic>;
//               String noteText = data['note']; 

//               // diplaying the note
//               return ListTile(
//                 title: Text(noteText),
//                 trailing: Row(
//                   mainAxisSize: MainAxisSize.min,
//                   mainAxisAlignment: MainAxisAlignment.end,
//                   children: [IconButton(
//                   onPressed: (){openNoteBox(docId: docId);}, 
//                   icon: Icon(Icons.settings)),
//                    IconButton(onPressed: (){firestoreService.deleteNode(docId);}, icon: Icon(Icons.delete))],
//                 )

//               );
//             });
//           }
//           else{
//             return Text("no notes found");
//           }
//         })
//     );
//   }
  

// }