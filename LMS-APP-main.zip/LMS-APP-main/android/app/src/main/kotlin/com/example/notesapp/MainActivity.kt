package com.example.notesapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
